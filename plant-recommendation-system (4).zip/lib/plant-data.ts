import Papa from "papaparse"

export interface PlantData {
  plant_id?: string
  common_name: string
  family: string
  categories: string
  origin: string
  climate: string
  zone: string
  img_url: string
  light_requirement?: string
  water_frequency?: number
  humidity_preference?: string
  maintenance_difficulty?: number
  pet_friendly?: boolean
  suitable_locations?: string
  care_difficulty?: string
  match_score?: number
}

// Cache the plant data to avoid fetching it multiple times
let cachedPlantData: PlantData[] | null = null

export async function fetchPlantData(): Promise<PlantData[]> {
  // Return cached data if available
  if (cachedPlantData) {
    return cachedPlantData
  }

  try {
    const response = await fetch(
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/plant_123-BZGCffrt6tLSAdC9JFYcioDlLW4yrB.csv",
    )

    if (!response.ok) {
      throw new Error(`Failed to fetch plant data: ${response.status} ${response.statusText}`)
    }

    const csvText = await response.text()

    // Parse CSV
    const { data } = Papa.parse(csvText, {
      header: true,
      skipEmptyLines: true,
    })

    // Process the data to match the format expected by the recommendation system
    const processedData = data.map((plant: any, index: number) => {
      return {
        plant_id: `P${(index + 1).toString().padStart(3, "0")}`,
        common_name: plant.common_name?.trim() || "Unknown Plant",
        family: plant.family || "",
        categories: plant.categories || "",
        origin: plant.origin || "",
        climate: plant.climate || "",
        zone: plant.zone || "",
        img_url: plant.img_url || "/placeholder.svg?height=200&width=400",
      }
    })

    // Add derived properties based on the Python preprocessing logic
    const enhancedData = processedData.map((plant: PlantData) => {
      const enhancedPlant = { ...plant }

      // Light requirement based on climate and categories
      enhancedPlant.light_requirement = "Medium" // Default

      if (plant.climate?.toLowerCase().includes("arid")) {
        enhancedPlant.light_requirement = "High"
      } else if (plant.categories?.toLowerCase().includes("fern") || plant.climate?.toLowerCase().includes("humid")) {
        enhancedPlant.light_requirement = "Low"
      } else if (
        plant.categories?.toLowerCase().includes("cactus") ||
        plant.categories?.toLowerCase().includes("succulent")
      ) {
        enhancedPlant.light_requirement = "High"
      }

      // Water frequency
      enhancedPlant.water_frequency = 7 // Default weekly

      if (
        plant.climate?.toLowerCase().includes("arid") ||
        plant.categories?.toLowerCase().includes("cactus") ||
        plant.categories?.toLowerCase().includes("succulent")
      ) {
        enhancedPlant.water_frequency = 14
      } else if (plant.climate?.toLowerCase().includes("humid")) {
        enhancedPlant.water_frequency = 5
      }

      // Humidity preference
      enhancedPlant.humidity_preference = "Medium" // Default

      if (plant.climate?.toLowerCase().includes("humid") || plant.categories?.toLowerCase().includes("fern")) {
        enhancedPlant.humidity_preference = "High"
      } else if (plant.climate?.toLowerCase().includes("arid")) {
        enhancedPlant.humidity_preference = "Low"
      }

      // Maintenance difficulty
      enhancedPlant.maintenance_difficulty = 2 // Default moderate
      enhancedPlant.care_difficulty = "Moderate"

      const easyPlants = ["snake plant", "zz plant", "pothos", "spider plant", "chinese evergreen"]
      const difficultPlants = ["calathea", "fiddle leaf fig", "orchid", "boston fern"]

      const plantNameLower = plant.common_name.toLowerCase()

      if (easyPlants.some((easy) => plantNameLower.includes(easy))) {
        enhancedPlant.maintenance_difficulty = 1
        enhancedPlant.care_difficulty = "Easy"
      } else if (difficultPlants.some((difficult) => plantNameLower.includes(difficult))) {
        enhancedPlant.maintenance_difficulty = 3
        enhancedPlant.care_difficulty = "Difficult"
      }

      // Pet friendliness
      enhancedPlant.pet_friendly = false // Default

      const petFriendlyPlants = ["spider plant", "boston fern", "parlor palm", "areca palm", "money plant"]
      if (petFriendlyPlants.some((friendly) => plantNameLower.includes(friendly))) {
        enhancedPlant.pet_friendly = true
      }

      // Suitable locations
      enhancedPlant.suitable_locations = "Living room" // Default

      if (enhancedPlant.humidity_preference === "High") {
        enhancedPlant.suitable_locations = "Bathroom, Living room"
      }

      const bedroomPlants = ["snake plant", "peace lily", "spider plant", "pothos", "english ivy"]
      if (bedroomPlants.some((bedroom) => plantNameLower.includes(bedroom))) {
        enhancedPlant.suitable_locations = "Bedroom, Living room"
      }

      const kitchenPlants = ["aloe", "herb", "spider plant"]
      if (kitchenPlants.some((kitchen) => plantNameLower.includes(kitchen))) {
        enhancedPlant.suitable_locations = "Kitchen, Living room"
      }

      const officePlants = ["snake plant", "zz plant", "pothos", "peace lily"]
      if (officePlants.some((office) => plantNameLower.includes(office))) {
        enhancedPlant.suitable_locations = "Office, Living room"
      }

      return enhancedPlant
    })

    // Cache the data
    cachedPlantData = enhancedData as PlantData[]

    return enhancedData as PlantData[]
  } catch (error) {
    console.error("Error fetching plant data:", error)
    return []
  }
}

export function calculateMatchScore(plant: PlantData, preferences: any): number {
  let score = 0
  let totalWeight = 0

  // Light preference matching
  if (preferences.light_level) {
    const weight = 3
    totalWeight += weight

    const userLight = preferences.light_level.toLowerCase()
    const plantLight = (plant.light_requirement || "Medium").toLowerCase()

    // Simple matching logic based on light levels
    const lightLevels: Record<string, number> = { low: 1, medium: 2, high: 3 }

    // Map text descriptions to standardized levels
    let mappedPlantLight = "medium" // Default
    for (const level of Object.keys(lightLevels)) {
      if (plantLight.includes(level)) {
        mappedPlantLight = level
        break
      }
    }

    // Handle medium-high or low-medium cases
    if (plantLight.includes("medium-high") || plantLight.includes("bright")) {
      mappedPlantLight = "high"
    } else if (plantLight.includes("low-medium") || plantLight.includes("partial")) {
      mappedPlantLight = "medium"
    }

    // Score based on how well the light levels match
    if (mappedPlantLight === userLight) {
      score += weight
    } else if (Math.abs((lightLevels[mappedPlantLight] || 2) - (lightLevels[userLight] || 2)) === 1) {
      // Adjacent light levels get partial score
      score += weight * 0.5
    }
  }

  // Maintenance preference matching
  if (preferences.maintenance) {
    const weight = 2
    totalWeight += weight

    const userMaintenance = preferences.maintenance.toLowerCase()
    const plantMaintenance = (plant.care_difficulty || "Moderate").toLowerCase()

    // Map various terms to standardized levels
    const maintMap: Record<string, string[]> = {
      low: ["easy", "simple", "beginner", "low"],
      medium: ["moderate", "average", "intermediate", "medium"],
      high: ["difficult", "challenging", "expert", "high"],
    }

    // Find standardized maintenance level
    let mappedPlantMaint = "medium" // Default
    for (const [level, terms] of Object.entries(maintMap)) {
      if (terms.some((term) => plantMaintenance.includes(term))) {
        mappedPlantMaint = level
        break
      }
    }

    // Score based on match
    if (mappedPlantMaint === userMaintenance) {
      score += weight
    } else {
      const maintLevels = Object.keys(maintMap)
      const plantIndex = maintLevels.indexOf(mappedPlantMaint)
      const userIndex = maintLevels.indexOf(userMaintenance)

      if (plantIndex !== -1 && userIndex !== -1 && Math.abs(plantIndex - userIndex) === 1) {
        // Adjacent maintenance levels get partial score
        score += weight * 0.5
      }
    }
  }

  // Pet safety preference
  if (preferences.pet_safe) {
    const weight = 3
    totalWeight += weight

    if (plant.pet_friendly) {
      score += weight
    }
  }

  // Room type matching
  if (preferences.room_type) {
    const weight = 2
    totalWeight += weight

    const userRoom = preferences.room_type.toLowerCase().replace("_", " ")
    const suitableLocations = (plant.suitable_locations || "Living room").toLowerCase()

    // Map room types for matching
    const roomMap: Record<string, string[]> = {
      "living room": ["living", "lounge", "family"],
      bedroom: ["bed", "sleeping"],
      bathroom: ["bath", "wash", "rest"],
      kitchen: ["kitchen", "cooking", "dining"],
      office: ["office", "study", "work"],
    }

    // Find which standard room type the user's preference maps to
    let userRoomCategory = userRoom
    for (const [roomType, terms] of Object.entries(roomMap)) {
      if (terms.some((term) => userRoom.includes(term))) {
        userRoomCategory = roomType
        break
      }
    }

    // Check if the room type is in suitable locations
    const roomTerms = roomMap[userRoomCategory] || [userRoomCategory]
    if (roomTerms.some((term) => suitableLocations.includes(term))) {
      score += weight
    }
  }

  // Normalize score
  return totalWeight > 0 ? score / totalWeight : 0
}

export function recommendPlants(plants: PlantData[], preferences: any, topN = 5): PlantData[] {
  // Calculate match scores for all plants
  const plantsWithScores = plants.map((plant) => {
    const matchScore = calculateMatchScore(plant, preferences)
    return { ...plant, match_score: matchScore }
  })

  // Sort by score in descending order and take top N
  return plantsWithScores.sort((a, b) => (b.match_score || 0) - (a.match_score || 0)).slice(0, topN)
}

export function explainRecommendation(plant: PlantData) {
  const explanation = {
    overall_score: plant.match_score || 0,
    factors: [] as any[],
  }

  // Light requirements
  const lightReq = plant.light_requirement || "Medium"
  explanation.factors.push({
    factor: "Light Requirements",
    value: lightReq,
    explanation: `This plant thrives in ${lightReq.toLowerCase()} light conditions.`,
  })

  // Maintenance level
  const care = plant.care_difficulty || "Moderate"
  const maintenanceExplanations: Record<string, string> = {
    Easy: "This plant is low-maintenance and forgiving, perfect for beginners or busy plant owners.",
    Moderate: "This plant requires regular attention but is not overly demanding.",
    Difficult: "This plant requires specific care and attention to thrive.",
  }
  explanation.factors.push({
    factor: "Maintenance Level",
    value: care,
    explanation: maintenanceExplanations[care] || "This plant has moderate care requirements.",
  })

  // Pet friendliness
  const petFriendly = plant.pet_friendly || false
  explanation.factors.push({
    factor: "Pet Safety",
    value: petFriendly ? "Pet-friendly" : "Not pet-friendly",
    explanation: petFriendly
      ? "This plant is safe for households with pets."
      : "This plant may be toxic to pets and should be kept out of their reach.",
  })

  // Suitable locations
  const locations = plant.suitable_locations || "Living room"
  explanation.factors.push({
    factor: "Suitable Locations",
    value: locations,
    explanation: `This plant is well-suited for placement in: ${locations}.`,
  })

  // Climate adaptation
  const climate = plant.climate || "Tropical"
  explanation.factors.push({
    factor: "Natural Habitat",
    value: climate,
    explanation: `This plant naturally grows in ${climate.toLowerCase()} conditions.`,
  })

  return explanation
}
