"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { useToast } from "@/components/ui/use-toast"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Clock, Utensils, Heart, ChefHat, Search } from "lucide-react"
import { Input } from "@/components/ui/input"

export default function RecipesPage() {
  const { toast } = useToast()
  const [isLoading, setIsLoading] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")
  const [recipes, setRecipes] = useState<any>(null)
  const [selectedPlant, setSelectedPlant] = useState("Mint")

  const popularEdiblePlants = [
    "Mint",
    "Basil",
    "Rosemary",
    "Thyme",
    "Lavender",
    "Sage",
    "Oregano",
    "Chives",
    "Parsley",
    "Cilantro",
    "Aloe Vera",
  ]

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    if (!searchQuery.trim()) return

    setIsLoading(true)
    fetchRecipes(searchQuery)
  }

  const handlePlantSelect = (plant: string) => {
    setSelectedPlant(plant)
    setSearchQuery(plant)
    fetchRecipes(plant)
  }

  const fetchRecipes = async (plantName: string) => {
    try {
      const response = await fetch("/api/plant-recipes", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          plant_name: plantName,
        }),
      })

      if (!response.ok) {
        throw new Error("Failed to fetch recipes")
      }

      const data = await response.json()
      setRecipes(data.recipes)

      toast({
        title: "Recipes found!",
        description: `Found ${data.recipes.length} recipes using ${plantName}.`,
      })
    } catch (error) {
      console.error("Error fetching recipes:", error)
      toast({
        title: "Error",
        description: "Failed to fetch recipes. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  useEffect(() => {
    fetchRecipes("Mint")
  }, []) // Empty dependency array means this runs once on mount

  return (
    <div className="container mx-auto py-12 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <h1 className="text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl mb-4">Plant-Based Recipes</h1>
          <p className="text-lg text-gray-600">
            Discover culinary and wellness uses for your edible indoor plants with our recipe database.
          </p>
        </div>

        <div className="grid grid-cols-1 gap-8">
          <Card>
            <CardHeader>
              <CardTitle>Find Recipes by Plant</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSearch} className="flex gap-2 mb-6">
                <div className="relative flex-grow">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
                  <Input
                    type="text"
                    placeholder="Search by plant name (e.g., Mint, Basil)"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-9"
                  />
                </div>
                <Button type="submit" disabled={isLoading} className="bg-green-600 hover:bg-green-700">
                  {isLoading ? "Searching..." : "Search"}
                </Button>
              </form>

              <div className="mb-6">
                <h3 className="text-sm font-medium text-gray-700 mb-2">Popular Edible Plants</h3>
                <div className="flex flex-wrap gap-2">
                  {popularEdiblePlants.map((plant) => (
                    <Badge
                      key={plant}
                      variant="outline"
                      className={`cursor-pointer hover:bg-green-50 ${
                        selectedPlant === plant ? "bg-green-100 text-green-800 border-green-200" : ""
                      }`}
                      onClick={() => handlePlantSelect(plant)}
                    >
                      {plant}
                    </Badge>
                  ))}
                </div>
              </div>

              {recipes && (
                <Tabs defaultValue="culinary" className="w-full">
                  <TabsList className="grid w-full grid-cols-2">
                    <TabsTrigger value="culinary">Culinary Recipes</TabsTrigger>
                    <TabsTrigger value="wellness">Wellness Uses</TabsTrigger>
                  </TabsList>
                  <TabsContent value="culinary" className="space-y-4 pt-4">
                    {recipes
                      .filter((recipe: any) => !recipe.name.includes("Face") && !recipe.name.includes("Infused"))
                      .map((recipe: any, index: number) => (
                        <Card key={index}>
                          <CardContent className="p-6">
                            <div className="flex flex-col md:flex-row gap-4">
                              <div className="md:w-1/4">
                                <div className="aspect-square rounded-lg bg-gray-100 overflow-hidden">
                                  {recipe.imageUrl ? (
                                    <img
                                      src={recipe.imageUrl || "/placeholder.svg"}
                                      alt={recipe.name}
                                      className="w-full h-full object-cover"
                                    />
                                  ) : (
                                    <Utensils className="h-12 w-12 text-green-500 m-auto" />
                                  )}
                                </div>
                              </div>
                              <div className="md:w-3/4 space-y-3">
                                <h3 className="text-xl font-medium">{recipe.name}</h3>

                                <div className="flex flex-wrap gap-2">
                                  <Badge variant="outline" className="flex items-center gap-1">
                                    <Clock className="h-3 w-3" />
                                    <span>15-30 min</span>
                                  </Badge>
                                  <Badge variant="outline" className="flex items-center gap-1">
                                    <ChefHat className="h-3 w-3" />
                                    <span>Easy</span>
                                  </Badge>
                                  <Badge
                                    variant="outline"
                                    className="flex items-center gap-1 bg-green-50 text-green-700"
                                  >
                                    <Heart className="h-3 w-3" />
                                    <span>{recipe.benefits}</span>
                                  </Badge>
                                </div>

                                <div>
                                  <h4 className="font-medium mb-1">Ingredients:</h4>
                                  <ul className="list-disc pl-5 text-sm text-gray-600 grid grid-cols-1 sm:grid-cols-2 gap-1">
                                    {recipe.ingredients.map((ingredient: string, idx: number) => (
                                      <li key={idx}>{ingredient}</li>
                                    ))}
                                  </ul>
                                </div>

                                <div>
                                  <h4 className="font-medium mb-1">Instructions:</h4>
                                  <p className="text-sm text-gray-600">{recipe.instructions}</p>
                                </div>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                  </TabsContent>
                  <TabsContent value="wellness" className="space-y-4 pt-4">
                    {recipes
                      .filter((recipe: any) => recipe.name.includes("Face") || recipe.name.includes("Infused"))
                      .map((recipe: any, index: number) => (
                        <Card key={index}>
                          <CardContent className="p-6">
                            <div className="flex flex-col md:flex-row gap-4">
                              <div className="md:w-1/4">
                                <div className="aspect-square rounded-lg bg-gray-100 overflow-hidden">
                                  {recipe.imageUrl ? (
                                    <img
                                      src={recipe.imageUrl || "/placeholder.svg"}
                                      alt={recipe.name}
                                      className="w-full h-full object-cover"
                                    />
                                  ) : (
                                    <Heart className="h-12 w-12 text-pink-500 m-auto" />
                                  )}
                                </div>
                              </div>
                              <div className="md:w-3/4 space-y-3">
                                <h3 className="text-xl font-medium">{recipe.name}</h3>

                                <div className="flex flex-wrap gap-2">
                                  <Badge variant="outline" className="flex items-center gap-1">
                                    <Clock className="h-3 w-3" />
                                    <span>10-20 min</span>
                                  </Badge>
                                  <Badge variant="outline" className="flex items-center gap-1 bg-pink-50 text-pink-700">
                                    <Heart className="h-3 w-3" />
                                    <span>{recipe.benefits}</span>
                                  </Badge>
                                </div>

                                <div>
                                  <h4 className="font-medium mb-1">Ingredients:</h4>
                                  <ul className="list-disc pl-5 text-sm text-gray-600 grid grid-cols-1 sm:grid-cols-2 gap-1">
                                    {recipe.ingredients.map((ingredient: string, idx: number) => (
                                      <li key={idx}>{ingredient}</li>
                                    ))}
                                  </ul>
                                </div>

                                <div>
                                  <h4 className="font-medium mb-1">Instructions:</h4>
                                  <p className="text-sm text-gray-600">{recipe.instructions}</p>
                                </div>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                  </TabsContent>
                </Tabs>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
