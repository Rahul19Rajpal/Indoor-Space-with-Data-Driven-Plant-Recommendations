"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { useToast } from "@/components/ui/use-toast"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Checkbox } from "@/components/ui/checkbox"
import { Badge } from "@/components/ui/badge"
import { Wind, Leaf, AlertTriangle, Info } from "lucide-react"

export default function AirQualityPage() {
  const { toast } = useToast()
  const [isLoading, setIsLoading] = useState(false)
  const [recommendations, setRecommendations] = useState<any>(null)
  const [formData, setFormData] = useState({
    roomSize: "medium",
    pollutants: {
      benzene: false,
      formaldehyde: false,
      trichloroethylene: false,
      xylene: false,
      ammonia: false,
      carbonMonoxide: false,
    },
  })

  const handleRoomSizeChange = (value: string) => {
    setFormData((prev) => ({
      ...prev,
      roomSize: value,
    }))
  }

  const handlePollutantChange = (pollutant: string, checked: boolean) => {
    setFormData((prev) => ({
      ...prev,
      pollutants: {
        ...prev.pollutants,
        [pollutant]: checked,
      },
    }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    // Get selected pollutants
    const selectedPollutants = Object.entries(formData.pollutants)
      .filter(([_, selected]) => selected)
      .map(([name]) => name)

    try {
      const response = await fetch("/api/air-quality-plants", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          roomSize: formData.roomSize,
          pollutants: selectedPollutants.length > 0 ? selectedPollutants : undefined,
        }),
      })

      if (!response.ok) {
        throw new Error("Failed to get air quality recommendations")
      }

      const data = await response.json()
      setRecommendations(data.recommendations)

      toast({
        title: "Recommendations ready!",
        description: "We've found the best plants for your air quality needs.",
      })
    } catch (error) {
      console.error("Error getting air quality recommendations:", error)
      toast({
        title: "Error",
        description: "Failed to get recommendations. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="container mx-auto py-12 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <h1 className="text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl mb-4">
            Air Quality Monitoring & Recommendations
          </h1>
          <p className="text-lg text-gray-600">
            Get plant recommendations to improve air quality and target specific pollutants in your space.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="md:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle>Air Quality Parameters</CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="space-y-3">
                    <Label>Room Size</Label>
                    <RadioGroup
                      defaultValue={formData.roomSize}
                      onValueChange={handleRoomSizeChange}
                      className="grid grid-cols-1 gap-2"
                    >
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="small" id="small" />
                        <Label htmlFor="small">Small (up to 150 sq ft)</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="medium" id="medium" />
                        <Label htmlFor="medium">Medium (150-300 sq ft)</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="large" id="large" />
                        <Label htmlFor="large">Large (300+ sq ft)</Label>
                      </div>
                    </RadioGroup>
                  </div>

                  <div className="space-y-3">
                    <Label>Target Pollutants (Optional)</Label>
                    <div className="grid grid-cols-1 gap-2">
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="benzene"
                          checked={formData.pollutants.benzene}
                          onCheckedChange={(checked) => handlePollutantChange("benzene", checked === true)}
                        />
                        <Label htmlFor="benzene" className="text-sm">
                          Benzene (paints, plastics, tobacco smoke)
                        </Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="formaldehyde"
                          checked={formData.pollutants.formaldehyde}
                          onCheckedChange={(checked) => handlePollutantChange("formaldehyde", checked === true)}
                        />
                        <Label htmlFor="formaldehyde" className="text-sm">
                          Formaldehyde (furniture, carpets)
                        </Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="trichloroethylene"
                          checked={formData.pollutants.trichloroethylene}
                          onCheckedChange={(checked) => handlePollutantChange("trichloroethylene", checked === true)}
                        />
                        <Label htmlFor="trichloroethylene" className="text-sm">
                          Trichloroethylene (cleaning products)
                        </Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="xylene"
                          checked={formData.pollutants.xylene}
                          onCheckedChange={(checked) => handlePollutantChange("xylene", checked === true)}
                        />
                        <Label htmlFor="xylene" className="text-sm">
                          Xylene (printing, rubber, leather)
                        </Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="ammonia"
                          checked={formData.pollutants.ammonia}
                          onCheckedChange={(checked) => handlePollutantChange("ammonia", checked === true)}
                        />
                        <Label htmlFor="ammonia" className="text-sm">
                          Ammonia (cleaning products)
                        </Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="carbonMonoxide"
                          checked={formData.pollutants.carbonMonoxide}
                          onCheckedChange={(checked) => handlePollutantChange("carbonMonoxide", checked === true)}
                        />
                        <Label htmlFor="carbonMonoxide" className="text-sm">
                          Carbon Monoxide (combustion)
                        </Label>
                      </div>
                    </div>
                  </div>

                  <Button type="submit" disabled={isLoading} className="w-full bg-green-600 hover:bg-green-700">
                    {isLoading ? "Getting Recommendations..." : "Get Recommendations"}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>

          <div className="md:col-span-2">
            {recommendations ? (
              <Card>
                <CardHeader>
                  <CardTitle>Recommended Air-Purifying Plants</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="rounded-lg bg-blue-50 p-4 border border-blue-100">
                    <div className="flex items-start gap-3">
                      <Info className="h-5 w-5 text-blue-500 mt-0.5" />
                      <div>
                        <h3 className="font-medium text-blue-800 mb-1">Air Quality Tips</h3>
                        <p className="text-sm text-blue-700">
                          For optimal air purification, use 1-2 plants per 100 square feet. Place plants in areas where
                          you spend the most time, and ensure they receive adequate light for their specific needs.
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    {recommendations.map((plant: any, index: number) => (
                      <div key={index} className="rounded-lg border p-4 hover:shadow-sm transition-shadow">
                        <div className="flex flex-col sm:flex-row gap-4">
                          <div className="sm:w-1/4">
                            <div className="aspect-square rounded-lg overflow-hidden bg-gray-100">
                              <img
                                src={plant.img_url || "/placeholder.svg?height=200&width=200"}
                                alt={plant.common_name}
                                className="w-full h-full object-cover"
                              />
                            </div>
                          </div>
                          <div className="sm:w-3/4 space-y-3">
                            <div>
                              <h3 className="text-lg font-medium">{plant.common_name}</h3>
                              <p className="text-sm text-gray-500">{plant.family}</p>
                            </div>

                            <div>
                              <h4 className="text-sm font-medium mb-1">Targets Pollutants:</h4>
                              <div className="flex flex-wrap gap-2">
                                {plant.targeted_pollutants?.map((pollutant: string, idx: number) => (
                                  <Badge key={idx} variant="outline" className="bg-green-50 text-green-700">
                                    {pollutant}
                                  </Badge>
                                ))}
                              </div>
                            </div>

                            <div className="grid grid-cols-2 gap-2 text-sm">
                              <div className="flex items-center gap-1">
                                <Wind className="h-4 w-4 text-blue-500" />
                                <span>Light: {plant.light_requirement}</span>
                              </div>
                              <div className="flex items-center gap-1">
                                <Leaf className="h-4 w-4 text-green-500" />
                                <span>Care: {plant.care_difficulty}</span>
                              </div>
                            </div>

                            {!plant.pet_friendly && (
                              <div className="flex items-center gap-1 text-sm text-amber-600">
                                <AlertTriangle className="h-4 w-4" />
                                <span>Not pet friendly</span>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ) : (
              <Card className="h-full flex items-center justify-center">
                <CardContent className="text-center py-12">
                  <div className="mb-4">
                    <div className="h-24 w-24 rounded-full bg-green-100 mx-auto flex items-center justify-center">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="48"
                        height="48"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="text-green-600"
                      >
                        <path d="M8 2v2" />
                        <path d="M16 2v2" />
                        <path d="M8 20v2" />
                        <path d="M16 20v2" />
                        <path d="M2 8h2" />
                        <path d="M2 16h2" />
                        <path d="M20 8h2" />
                        <path d="M20 16h2" />
                        <circle cx="12" cy="12" r="8" />
                      </svg>
                    </div>
                  </div>
                  <h3 className="text-xl font-medium mb-2">Breathe Better with Plants</h3>
                  <p className="text-gray-600 mb-6">
                    Select your room size and target pollutants to get personalized plant recommendations for improving
                    your indoor air quality.
                  </p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
