"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { useToast } from "@/components/ui/use-toast"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Slider } from "@/components/ui/slider"

export default function ArrangementDesignPage() {
  const { toast } = useToast()
  const [isGenerating, setIsGenerating] = useState(false)
  const [arrangement, setArrangement] = useState<any>(null)
  const [formData, setFormData] = useState({
    roomType: "living_room",
    style: "modern",
    numPlants: 3,
  })

  const handleStyleChange = (value: string) => {
    setFormData((prev) => ({
      ...prev,
      style: value,
    }))
  }

  const handleRoomTypeChange = (value: string) => {
    setFormData((prev) => ({
      ...prev,
      roomType: value,
    }))
  }

  const handleNumPlantsChange = (value: number[]) => {
    setFormData((prev) => ({
      ...prev,
      numPlants: value[0],
    }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsGenerating(true)

    try {
      const response = await fetch("/api/generate-arrangement", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          roomType: formData.roomType,
          style: formData.style,
          numPlants: formData.numPlants,
        }),
      })

      if (!response.ok) {
        throw new Error("Failed to generate arrangement")
      }

      const data = await response.json()
      setArrangement(data.recommendedArrangement)

      toast({
        title: "Arrangement generated!",
        description: "Your plant arrangement has been created.",
      })
    } catch (error) {
      console.error("Error generating arrangement:", error)
      toast({
        title: "Error",
        description: "Failed to generate arrangement. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsGenerating(false)
    }
  }

  return (
    <div className="container mx-auto py-12 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <h1 className="text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl mb-4">
            Generative Plant Arrangement Design
          </h1>
          <p className="text-lg text-gray-600">
            Create custom plant arrangements based on your room type, style preferences, and space constraints.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="md:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle>Design Parameters</CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="space-y-2">
                    <Label>Room Type</Label>
                    <RadioGroup
                      defaultValue={formData.roomType}
                      onValueChange={handleRoomTypeChange}
                      className="grid grid-cols-1 gap-2"
                    >
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="living_room" id="living_room" />
                        <Label htmlFor="living_room">Living Room</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="bedroom" id="bedroom" />
                        <Label htmlFor="bedroom">Bedroom</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="kitchen" id="kitchen" />
                        <Label htmlFor="kitchen">Kitchen</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="bathroom" id="bathroom" />
                        <Label htmlFor="bathroom">Bathroom</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="office" id="office" />
                        <Label htmlFor="office">Office</Label>
                      </div>
                    </RadioGroup>
                  </div>

                  <div className="space-y-2">
                    <Label>Style</Label>
                    <RadioGroup
                      defaultValue={formData.style}
                      onValueChange={handleStyleChange}
                      className="grid grid-cols-1 gap-2"
                    >
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="modern" id="modern" />
                        <Label htmlFor="modern">Modern</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="tropical" id="tropical" />
                        <Label htmlFor="tropical">Tropical</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="minimalist" id="minimalist" />
                        <Label htmlFor="minimalist">Minimalist</Label>
                      </div>
                    </RadioGroup>
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <Label>Number of Plants</Label>
                      <span className="text-sm text-gray-500">{formData.numPlants}</span>
                    </div>
                    <Slider
                      defaultValue={[formData.numPlants]}
                      min={1}
                      max={7}
                      step={1}
                      onValueChange={handleNumPlantsChange}
                    />
                  </div>

                  <Button type="submit" disabled={isGenerating} className="w-full bg-green-600 hover:bg-green-700">
                    {isGenerating ? "Generating..." : "Generate Arrangement"}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>

          <div className="md:col-span-2">
            {arrangement ? (
              <Card>
                <CardHeader>
                  <CardTitle>{arrangement.name}</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="aspect-video rounded-lg overflow-hidden bg-gray-100">
                    <img
                      src={arrangement.imageUrl || "/placeholder.svg?height=400&width=600"}
                      alt={arrangement.name}
                      className="w-full h-full object-cover"
                    />
                  </div>

                  <div>
                    <h3 className="font-medium text-lg mb-2">Description</h3>
                    <p className="text-gray-700">{arrangement.description}</p>
                  </div>

                  <div>
                    <h3 className="font-medium text-lg mb-2">Plants</h3>
                    <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {arrangement.plants.map((plant: any, index: number) => (
                        <li key={index} className="flex items-center gap-2">
                          <span className="h-2 w-2 rounded-full bg-green-500"></span>
                          <span>
                            {plant.name} ({plant.position})
                          </span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <h3 className="font-medium mb-1">Style</h3>
                      <p className="text-gray-700">{arrangement.style}</p>
                    </div>
                    <div>
                      <h3 className="font-medium mb-1">Care Level</h3>
                      <p className="text-gray-700">{arrangement.careLevel}</p>
                    </div>
                    <div>
                      <h3 className="font-medium mb-1">Light Requirement</h3>
                      <p className="text-gray-700">{arrangement.lightRequirement}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ) : (
              <Card className="h-full flex items-center justify-center">
                <CardContent className="text-center py-12">
                  <div className="mb-4">
                    <div className="h-24 w-24 rounded-full bg-green-100 mx-auto flex items-center justify-center">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="48"
                        height="48"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="text-green-600"
                      >
                        <path d="M2 22c1.25-1.25 2.5-2.5 3.5-2.5 1.5 0 2.5 1.5 4 1.5s2.5-1.5 4-1.5 2.5 1.5 4 1.5 2.5-1.5 3.5-2.5" />
                        <path d="M19 17c.5-1 1-2 1-3.5C20 8.5 16 3 12 3S4 8.5 4 13.5c0 1.5.5 2.5 1 3.5" />
                      </svg>
                    </div>
                  </div>
                  <h3 className="text-xl font-medium mb-2">Generate Your Plant Arrangement</h3>
                  <p className="text-gray-600 mb-6">
                    Select your preferences and click "Generate Arrangement" to create a custom plant design for your
                    space.
                  </p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
