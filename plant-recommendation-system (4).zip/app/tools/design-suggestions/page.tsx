"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { useToast } from "@/components/ui/use-toast"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { PaintBucket, Palette, Home } from "lucide-react"

export default function DesignSuggestionsPage() {
  // Add this at the top of the component
  const designImages = {
    pot_style: [
      "https://images.unsplash.com/photo-1622547748225-3fc4abd2cca0?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1604762512526-b7068f861892?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1622547748225-3fc4abd2cca0?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    ],
    color_scheme: [
      "https://images.unsplash.com/photo-1556020685-ae41abfc9365?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1617104678098-de229db51175?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1615529162924-f8605388461d?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    ],
    complementary_items: [
      "https://images.unsplash.com/photo-1586023492125-27b2c045efd7?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1556228578-0d85b1a4d571?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1583847268964-b28dc8f51f92?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1616486338812-3dadae4b4ace?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    ],
  }
  const { toast } = useToast()
  const [isLoading, setIsLoading] = useState(false)
  const [suggestions, setSuggestions] = useState<any>(null)
  const [formData, setFormData] = useState({
    roomType: "living_room",
    plantType: "snake_plant",
  })

  const handleRoomTypeChange = (value: string) => {
    setFormData((prev) => ({
      ...prev,
      roomType: value,
    }))
  }

  const handlePlantTypeChange = (value: string) => {
    setFormData((prev) => ({
      ...prev,
      plantType: value,
    }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      const response = await fetch("/api/design-suggestions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          room_type: formData.roomType,
          plant_id: formData.plantType,
        }),
      })

      if (!response.ok) {
        throw new Error("Failed to get design suggestions")
      }

      const data = await response.json()
      setSuggestions(data.decor_suggestions)

      toast({
        title: "Design suggestions ready!",
        description: "We've created design ideas that complement your plants.",
      })
    } catch (error) {
      console.error("Error getting design suggestions:", error)
      toast({
        title: "Error",
        description: "Failed to get design suggestions. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  // Sample plant options
  const plantOptions = [
    { value: "snake_plant", label: "Snake Plant" },
    { value: "monstera", label: "Monstera" },
    { value: "fiddle_leaf_fig", label: "Fiddle Leaf Fig" },
    { value: "pothos", label: "Pothos" },
    { value: "zz_plant", label: "ZZ Plant" },
    { value: "peace_lily", label: "Peace Lily" },
    { value: "spider_plant", label: "Spider Plant" },
    { value: "rubber_plant", label: "Rubber Plant" },
  ]

  // Sample design suggestions (would come from API)
  const sampleSuggestions = {
    pot_style: [
      "Terracotta pots with minimalist design",
      "Concrete geometric planters",
      "Small ceramic pots with drainage",
    ],
    color_scheme: [
      "Neutral tones with gold accents",
      "Black and white with green highlights",
      "Earth tones with terracotta accents",
    ],
    complementary_items: [
      "Natural fiber throw pillows",
      "Wooden or rattan furniture",
      "Botanical art prints",
      "Natural fiber rugs",
    ],
  }

  return (
    <div className="container mx-auto py-12 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <h1 className="text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl mb-4">
            Plant-Inspired Design Suggestions
          </h1>
          <p className="text-lg text-gray-600">
            Get decor ideas that complement your plant collection and enhance your space.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="md:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle>Design Parameters</CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="space-y-3">
                    <Label>Room Type</Label>
                    <RadioGroup
                      defaultValue={formData.roomType}
                      onValueChange={handleRoomTypeChange}
                      className="grid grid-cols-1 gap-2"
                    >
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="living_room" id="living_room" />
                        <Label htmlFor="living_room">Living Room</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="bedroom" id="bedroom" />
                        <Label htmlFor="bedroom">Bedroom</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="kitchen" id="kitchen" />
                        <Label htmlFor="kitchen">Kitchen</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="bathroom" id="bathroom" />
                        <Label htmlFor="bathroom">Bathroom</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="office" id="office" />
                        <Label htmlFor="office">Office</Label>
                      </div>
                    </RadioGroup>
                  </div>

                  <div className="space-y-3">
                    <Label>Plant Type</Label>
                    <Select value={formData.plantType} onValueChange={handlePlantTypeChange}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select a plant" />
                      </SelectTrigger>
                      <SelectContent>
                        {plantOptions.map((option) => (
                          <SelectItem key={option.value} value={option.value}>
                            {option.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <Button type="submit" disabled={isLoading} className="w-full bg-green-600 hover:bg-green-700">
                    {isLoading ? "Generating Ideas..." : "Get Design Ideas"}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>

          <div className="md:col-span-2">
            {suggestions ? (
              <Card>
                <CardHeader>
                  <CardTitle>Design Suggestions</CardTitle>
                </CardHeader>
                <CardContent>
                  <Tabs defaultValue="pot_style" className="w-full">
                    <TabsList className="grid w-full grid-cols-3">
                      <TabsTrigger value="pot_style">Pot Styles</TabsTrigger>
                      <TabsTrigger value="color_scheme">Color Schemes</TabsTrigger>
                      <TabsTrigger value="complementary_items">Complementary Items</TabsTrigger>
                    </TabsList>
                    <TabsContent value="pot_style" className="space-y-4 pt-4">
                      <div className="flex items-center gap-3 mb-4">
                        <div className="h-10 w-10 rounded-full bg-amber-100 flex items-center justify-center">
                          <PaintBucket className="h-5 w-5 text-amber-600" />
                        </div>
                        <h3 className="text-lg font-medium">Recommended Pot Styles</h3>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        {suggestions.pot_style.map((style: string, index: number) => (
                          <Card key={index}>
                            <CardContent className="p-4 flex items-center gap-3">
                              <div className="h-12 w-12 rounded-lg overflow-hidden">
                                <img
                                  src={
                                    designImages.pot_style[index % designImages.pot_style.length] || "/placeholder.svg"
                                  }
                                  alt={style}
                                  className="w-full h-full object-cover"
                                />
                              </div>
                              <div>
                                <p className="font-medium">{style}</p>
                              </div>
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    </TabsContent>
                    <TabsContent value="color_scheme" className="space-y-4 pt-4">
                      <div className="flex items-center gap-3 mb-4">
                        <div className="h-10 w-10 rounded-full bg-purple-100 flex items-center justify-center">
                          <Palette className="h-5 w-5 text-purple-600" />
                        </div>
                        <h3 className="text-lg font-medium">Recommended Color Schemes</h3>
                      </div>

                      <div className="grid grid-cols-1 gap-4">
                        {suggestions.color_scheme.map((scheme: string, index: number) => (
                          <Card key={index}>
                            <CardContent className="p-4 flex items-center gap-3">
                              <div className="h-12 w-12 rounded-lg overflow-hidden">
                                <img
                                  src={
                                    designImages.color_scheme[index % designImages.color_scheme.length] ||
                                    "/placeholder.svg"
                                  }
                                  alt={scheme}
                                  className="w-full h-full object-cover"
                                />
                              </div>
                              <div>
                                <p className="font-medium">{scheme}</p>
                              </div>
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    </TabsContent>
                    <TabsContent value="complementary_items" className="space-y-4 pt-4">
                      <div className="flex items-center gap-3 mb-4">
                        <div className="h-10 w-10 rounded-full bg-blue-100 flex items-center justify-center">
                          <Home className="h-5 w-5 text-blue-600" />
                        </div>
                        <h3 className="text-lg font-medium">Complementary Items</h3>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        {suggestions.complementary_items.map((item: string, index: number) => (
                          <Card key={index}>
                            <CardContent className="p-4 flex items-center gap-3">
                              <div className="h-12 w-12 rounded-lg overflow-hidden">
                                <img
                                  src={
                                    designImages.complementary_items[index % designImages.complementary_items.length] ||
                                    "/placeholder.svg"
                                  }
                                  alt={item}
                                  className="w-full h-full object-cover"
                                />
                              </div>
                              <div>
                                <p className="font-medium">{item}</p>
                              </div>
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    </TabsContent>
                  </Tabs>
                </CardContent>
              </Card>
            ) : (
              <Card className="h-full flex items-center justify-center">
                <CardContent className="text-center py-12">
                  <div className="mb-4">
                    <div className="h-24 w-24 rounded-full bg-green-100 mx-auto flex items-center justify-center">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="48"
                        height="48"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="text-green-600"
                      >
                        <path d="M12 2v8" />
                        <path d="M4.93 10.93 12 18" />
                        <path d="M19.07 10.93 12 18" />
                        <path d="M22 22H2" />
                        <path d="M12 18v4" />
                      </svg>
                    </div>
                  </div>
                  <h3 className="text-xl font-medium mb-2">Design Your Plant Space</h3>
                  <p className="text-gray-600 mb-6">
                    Select your room type and plant to get personalized design suggestions that will enhance your space.
                  </p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
