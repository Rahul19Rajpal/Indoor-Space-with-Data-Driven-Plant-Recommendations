"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { useToast } from "@/components/ui/use-toast"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Upload, X } from "lucide-react"

export default function DiseaseDetectionPage() {
  const { toast } = useToast()
  const [isUploading, setIsUploading] = useState(false)
  const [uploadProgress, setUploadProgress] = useState(0)
  const [selectedFile, setSelectedFile] = useState<File | null>(null)
  const [previewUrl, setPreviewUrl] = useState<string | null>(null)
  const [detectionResults, setDetectionResults] = useState<any>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0] || null
    if (file) {
      setSelectedFile(file)
      setPreviewUrl(URL.createObjectURL(file))
      setDetectionResults(null)
    }
  }

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
  }

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()

    const file = e.dataTransfer.files?.[0] || null
    if (file && file.type.startsWith("image/")) {
      setSelectedFile(file)
      setPreviewUrl(URL.createObjectURL(file))
      setDetectionResults(null)
    } else {
      toast({
        title: "Invalid file type",
        description: "Please upload an image file.",
        variant: "destructive",
      })
    }
  }

  const handleUploadClick = () => {
    fileInputRef.current?.click()
  }

  const handleClearFile = () => {
    setSelectedFile(null)
    setPreviewUrl(null)
    setDetectionResults(null)
    if (fileInputRef.current) {
      fileInputRef.current.value = ""
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!selectedFile) return

    setIsUploading(true)
    setUploadProgress(0)

    // Simulate upload progress
    const progressInterval = setInterval(() => {
      setUploadProgress((prev) => {
        const newProgress = prev + 10
        if (newProgress >= 100) {
          clearInterval(progressInterval)
          return 100
        }
        return newProgress
      })
    }, 200)

    try {
      const formData = new FormData()
      formData.append("image", selectedFile)

      const response = await fetch("/api/plant-disease-detection", {
        method: "POST",
        body: formData,
      })

      if (!response.ok) {
        throw new Error("Failed to detect plant disease")
      }

      clearInterval(progressInterval)
      setUploadProgress(100)

      const data = await response.json()
      setDetectionResults(data)

      toast({
        title: "Analysis complete!",
        description: "We've analyzed your plant image.",
      })
    } catch (error) {
      console.error("Error detecting plant disease:", error)
      toast({
        title: "Error",
        description: "Failed to analyze the image. Please try again.",
        variant: "destructive",
      })
    } finally {
      setTimeout(() => {
        setIsUploading(false)
      }, 500) // Keep progress bar at 100% for a moment
    }
  }

  const getConfidenceColor = (confidence: number) => {
    if (confidence >= 0.7) return "bg-green-100 text-green-800 border-green-200"
    if (confidence >= 0.4) return "bg-yellow-100 text-yellow-800 border-yellow-200"
    return "bg-red-100 text-red-800 border-red-200"
  }

  return (
    <div className="container mx-auto py-12 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <h1 className="text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl mb-4">
            Plant Disease and Pest Detection
          </h1>
          <p className="text-lg text-gray-600">
            Upload a photo of your plant to identify diseases, pests, and get treatment recommendations.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div>
            <Card>
              <CardHeader>
                <CardTitle>Upload Plant Image</CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit}>
                  <div
                    className={`border-2 border-dashed rounded-lg p-6 text-center ${
                      previewUrl ? "border-green-300 bg-green-50" : "border-gray-300 hover:border-gray-400"
                    }`}
                    onDragOver={handleDragOver}
                    onDrop={handleDrop}
                  >
                    <input
                      type="file"
                      ref={fileInputRef}
                      onChange={handleFileChange}
                      accept="image/*"
                      className="hidden"
                    />

                    {previewUrl ? (
                      <div className="space-y-4">
                        <div className="relative mx-auto max-w-xs">
                          <img
                            src={previewUrl || "/placeholder.svg"}
                            alt="Plant preview"
                            className="mx-auto max-h-48 rounded-lg object-contain"
                          />
                          <button
                            type="button"
                            onClick={handleClearFile}
                            className="absolute -top-2 -right-2 rounded-full bg-red-100 p-1 text-red-600 hover:bg-red-200"
                          >
                            <X size={16} />
                          </button>
                        </div>
                        <p className="text-sm text-gray-500">
                          {selectedFile?.name} ({(selectedFile?.size / 1024).toFixed(1)} KB)
                        </p>
                      </div>
                    ) : (
                      <div className="cursor-pointer space-y-2 py-4" onClick={handleUploadClick}>
                        <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-green-100">
                          <Upload className="h-6 w-6 text-green-600" />
                        </div>
                        <div className="text-sm font-medium">Click to upload or drag and drop</div>
                        <p className="text-xs text-gray-500">PNG, JPG or JPEG (max. 5MB)</p>
                      </div>
                    )}
                  </div>

                  {isUploading && (
                    <div className="mt-4 space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>Analyzing image...</span>
                        <span>{uploadProgress}%</span>
                      </div>
                      <Progress value={uploadProgress} className="h-2" />
                    </div>
                  )}

                  <Button
                    type="submit"
                    disabled={!selectedFile || isUploading}
                    className="mt-4 w-full bg-green-600 hover:bg-green-700"
                  >
                    {isUploading ? "Analyzing..." : "Analyze Image"}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>

          <div>
            {detectionResults ? (
              <Card>
                <CardHeader>
                  <CardTitle>Detection Results</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  {detectionResults.imageUrl && (
                    <div className="rounded-lg overflow-hidden border mb-4">
                      <img
                        src={detectionResults.imageUrl || "/placeholder.svg"}
                        alt="Analyzed plant"
                        className="w-full h-auto"
                      />
                    </div>
                  )}
                  <div className="rounded-lg bg-green-50 p-4 border border-green-100">
                    <h3 className="font-medium text-lg mb-2">Health Assessment</h3>
                    <p className="text-gray-700">{detectionResults.healthAssessment}</p>
                  </div>

                  <div>
                    <h3 className="font-medium text-lg mb-3">Detected Issues</h3>
                    <div className="space-y-4">
                      {detectionResults.detectedDiseases.map((disease: any, index: number) => (
                        <div
                          key={index}
                          className={`rounded-lg p-4 border ${
                            index === 0 ? "bg-red-50 border-red-100" : "bg-gray-50 border-gray-100"
                          }`}
                        >
                          <div className="flex justify-between items-start mb-2">
                            <h4 className="font-medium">{disease.name}</h4>
                            <Badge variant="outline" className={getConfidenceColor(disease.confidence)}>
                              {Math.round(disease.confidence * 100)}% Confidence
                            </Badge>
                          </div>
                          <p className="text-sm text-gray-600 mb-3">{disease.description}</p>

                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm">
                            <div>
                              <h5 className="font-medium text-gray-700 mb-1">Treatment</h5>
                              <p className="text-gray-600">{disease.treatment}</p>
                            </div>
                            <div>
                              <h5 className="font-medium text-gray-700 mb-1">Prevention</h5>
                              <p className="text-gray-600">{disease.prevention}</p>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ) : (
              <Card className="h-full flex items-center justify-center">
                <CardContent className="text-center py-12">
                  <div className="mb-4">
                    <div className="h-24 w-24 rounded-full bg-green-100 mx-auto flex items-center justify-center">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="48"
                        height="48"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="text-green-600"
                      >
                        <path d="M2 3h20" />
                        <path d="M21 3v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V3" />
                        <path d="m7 21 5-5 5 5" />
                      </svg>
                    </div>
                  </div>
                  <h3 className="text-xl font-medium mb-2">Upload a Plant Image</h3>
                  <p className="text-gray-600 mb-6">
                    Upload a clear photo of your plant's affected areas for accurate disease detection and treatment
                    recommendations.
                  </p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
