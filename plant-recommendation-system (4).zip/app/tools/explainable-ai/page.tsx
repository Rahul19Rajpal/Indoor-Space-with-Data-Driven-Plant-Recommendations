"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { useToast } from "@/components/ui/use-toast"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Droplets, Sun, ThermometerSun, Wind, Check, AlertTriangle, Info } from "lucide-react"
import Link from "next/link"

export default function ExplainableAIPage() {
  const { toast } = useToast()
  const [activeTab, setActiveTab] = useState("overview")

  // Add this function at the top of the component
  const getRandomScore = (min: number, max: number) => {
    return Math.floor(Math.random() * (max - min + 1)) + min
  }

  // This would typically come from an API call, but we'll use static data for this example
  const samplePlant = {
    plant_id: "P001",
    common_name: "Snake Plant",
    family: "Liliaceae",
    categories: "Sansevieria",
    origin: "South Africa",
    climate: "Tropical",
    zone: "[11,10]",
    img_url: "http://www.tropicopia.com/house-plant/thumbnails/5735.jpg",
    light_requirement: "Low",
    water_frequency: 14, // days
    humidity_preference: "Low",
    maintenance_difficulty: 1,
    care_difficulty: "Easy",
    pet_friendly: false,
    suitable_locations: "Living room, Bedroom",
    match_score: 92,
    explanation: {
      overall_score: 92,
      factors: [
        {
          factor: "Light Requirements",
          value: "Low",
          explanation:
            "This plant thrives in low light conditions, making it perfect for spaces with limited natural light.",
          importance: 30,
          score: 95,
        },
        {
          factor: "Maintenance Level",
          value: "Easy",
          explanation: "This plant is low-maintenance and forgiving, perfect for beginners or busy plant owners.",
          importance: 25,
          score: 100,
        },
        {
          factor: "Water Requirements",
          value: "Low",
          explanation:
            "This plant needs infrequent watering (every 2-3 weeks), making it drought-tolerant and forgiving if you occasionally forget to water.",
          importance: 20,
          score: 90,
        },
        {
          factor: "Air Purification",
          value: "High",
          explanation:
            "This plant is excellent at removing toxins like formaldehyde and benzene from the air, improving your indoor air quality.",
          importance: 15,
          score: 85,
        },
        {
          factor: "Pet Safety",
          value: "Not pet-friendly",
          explanation: "This plant may be toxic to pets and should be kept out of their reach.",
          importance: 10,
          score: 0,
        },
      ],
    },
    alternatives: [
      {
        name: "ZZ Plant",
        match_score: 88,
        key_difference: "Similar care needs, also not pet friendly, slightly less air purifying",
      },
      {
        name: "Pothos",
        match_score: 85,
        key_difference: "Similar light needs, requires more frequent watering, not pet friendly",
      },
      {
        name: "Spider Plant",
        match_score: 80,
        key_difference: "Pet friendly alternative, needs more light and water",
      },
    ],
  }

  // Update the match_score and factor scores
  const matchScore = getRandomScore(75, 98)
  samplePlant.match_score = matchScore

  samplePlant.explanation.overall_score = matchScore
  samplePlant.explanation.factors = samplePlant.explanation.factors.map((factor) => ({
    ...factor,
    score: getRandomScore(60, 100),
  }))

  samplePlant.alternatives = samplePlant.alternatives.map((alt) => ({
    ...alt,
    match_score: getRandomScore(60, matchScore - 5),
  }))

  return (
    <div className="container mx-auto py-12 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <h1 className="text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl mb-4">
            Explainable Plant Recommendations
          </h1>
          <p className="text-lg text-gray-600">
            Understand exactly why certain plants are recommended for your space with transparent AI explanations.
          </p>
        </div>

        <div className="grid grid-cols-1 gap-8">
          <Card>
            <CardHeader>
              <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                <div>
                  <CardTitle className="text-2xl">{samplePlant.common_name}</CardTitle>
                  <CardDescription>
                    {samplePlant.family} - {samplePlant.categories}
                  </CardDescription>
                </div>
                <Badge className="md:ml-auto text-lg px-3 py-1 bg-green-100 text-green-800 hover:bg-green-200">
                  {samplePlant.match_score}% Match
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex flex-col md:flex-row gap-6">
                <div className="md:w-1/3">
                  <div className="rounded-lg overflow-hidden bg-gray-100 aspect-square">
                    <img
                      src={samplePlant.img_url || "/placeholder.svg?height=300&width=300"}
                      alt={samplePlant.common_name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                </div>
                <div className="md:w-2/3">
                  <p className="text-gray-700 mb-4">
                    A {samplePlant.common_name.toLowerCase()} from {samplePlant.origin}, native to{" "}
                    {samplePlant.climate.toLowerCase()} climates. This plant is perfect for{" "}
                    {samplePlant.suitable_locations.toLowerCase()}.
                  </p>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="flex items-center">
                      <Sun className="h-5 w-5 text-yellow-500 mr-2" />
                      <span className="text-sm">Light: {samplePlant.light_requirement}</span>
                    </div>
                    <div className="flex items-center">
                      <Droplets className="h-5 w-5 text-blue-500 mr-2" />
                      <span className="text-sm">Water: Every {samplePlant.water_frequency} days</span>
                    </div>
                    <div className="flex items-center">
                      <Wind className="h-5 w-5 text-teal-500 mr-2" />
                      <span className="text-sm">Humidity: {samplePlant.humidity_preference}</span>
                    </div>
                    <div className="flex items-center">
                      <ThermometerSun className="h-5 w-5 text-orange-500 mr-2" />
                      <span className="text-sm">Maintenance: {samplePlant.care_difficulty}</span>
                    </div>
                  </div>
                  <div className="mt-4 flex items-center">
                    {samplePlant.pet_friendly ? (
                      <Badge
                        variant="outline"
                        className="bg-green-50 text-green-700 border-green-200 flex items-center"
                      >
                        <Check className="h-3 w-3 mr-1" /> Pet Friendly
                      </Badge>
                    ) : (
                      <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200 flex items-center">
                        <AlertTriangle className="h-3 w-3 mr-1" /> Not Pet Safe
                      </Badge>
                    )}
                  </div>
                </div>
              </div>

              <Tabs defaultValue="overview" value={activeTab} onValueChange={setActiveTab} className="w-full">
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="overview">Match Overview</TabsTrigger>
                  <TabsTrigger value="detailed">Detailed Analysis</TabsTrigger>
                  <TabsTrigger value="alternatives">Alternatives</TabsTrigger>
                </TabsList>
                <TabsContent value="overview" className="space-y-4 pt-4">
                  <div className="rounded-lg bg-blue-50 p-4 border border-blue-100">
                    <div className="flex items-start gap-3">
                      <Info className="h-5 w-5 text-blue-500 mt-0.5" />
                      <div>
                        <h3 className="font-medium text-blue-800 mb-1">How We Calculate Match Scores</h3>
                        <p className="text-sm text-blue-700">
                          Our AI analyzes your preferences and living conditions, then compares them with each plant's
                          requirements. The match score represents how well a plant meets your specific needs.
                        </p>
                      </div>
                    </div>
                  </div>

                  <h3 className="text-lg font-medium">Match Score Breakdown</h3>
                  <div className="space-y-4">
                    {samplePlant.explanation.factors.map((factor, index) => (
                      <div key={index} className="space-y-1">
                        <div className="flex justify-between items-center">
                          <div className="flex items-center gap-2">
                            <span className="font-medium">{factor.factor}</span>
                            <span className="text-sm text-gray-500">({factor.importance}% weight)</span>
                          </div>
                          <span className="font-medium">{factor.score}%</span>
                        </div>
                        <Progress value={factor.score} className="h-2" />
                        <p className="text-sm text-gray-600">{factor.explanation}</p>
                      </div>
                    ))}
                  </div>
                </TabsContent>
                <TabsContent value="detailed" className="space-y-4 pt-4">
                  <div className="space-y-6">
                    <div className="rounded-lg border p-4">
                      <h3 className="text-lg font-medium mb-2">Light Requirements</h3>
                      <p className="text-gray-700 mb-3">
                        Snake Plants thrive in low light conditions, though they can tolerate medium light as well. They
                        can survive in dimly lit corners where most plants would struggle, making them perfect for:
                      </p>
                      <ul className="list-disc pl-5 space-y-1 text-gray-600">
                        <li>North-facing windows with minimal direct light</li>
                        <li>Interior spaces away from windows</li>
                        <li>Offices with fluorescent lighting</li>
                      </ul>
                      <div className="mt-3 text-sm text-gray-500">
                        <strong>Your preference:</strong> Low light environment
                      </div>
                    </div>

                    <div className="rounded-lg border p-4">
                      <h3 className="text-lg font-medium mb-2">Water Requirements</h3>
                      <p className="text-gray-700 mb-3">
                        Snake Plants are extremely drought-tolerant and prefer to dry out completely between waterings.
                        Overwatering is the most common way to kill this plant. Watering once every 2-3 weeks is
                        typically sufficient.
                      </p>
                      <div className="mt-3 text-sm text-gray-500">
                        <strong>Your preference:</strong> Low maintenance watering schedule
                      </div>
                    </div>

                    <div className="rounded-lg border p-4">
                      <h3 className="text-lg font-medium mb-2">Air Purification Benefits</h3>
                      <p className="text-gray-700 mb-3">
                        NASA's Clean Air Study found that Snake Plants are one of the most effective plants for removing
                        indoor air pollutants, particularly:
                      </p>
                      <ul className="list-disc pl-5 space-y-1 text-gray-600">
                        <li>Formaldehyde (found in cleaning products, paper goods)</li>
                        <li>Benzene (found in paints, furniture wax, detergents)</li>
                        <li>Xylene (found in printing, rubber, leather)</li>
                        <li>Trichloroethylene (found in adhesives, paint removers)</li>
                      </ul>
                      <div className="mt-3 text-sm text-gray-500">
                        <strong>Your preference:</strong> Air purifying capabilities
                      </div>
                    </div>

                    <div className="rounded-lg border p-4">
                      <h3 className="text-lg font-medium mb-2">Pet Safety Considerations</h3>
                      <p className="text-gray-700 mb-3">
                        Snake Plants contain saponins which can cause mild toxicity if ingested by pets. Symptoms may
                        include nausea, vomiting, and diarrhea. While rarely fatal, it's recommended to keep this plant
                        out of reach of pets.
                      </p>
                      <div className="mt-3 text-sm text-gray-500">
                        <strong>Your preference:</strong> You indicated having pets
                      </div>
                    </div>
                  </div>
                </TabsContent>
                <TabsContent value="alternatives" className="space-y-4 pt-4">
                  <div className="rounded-lg bg-blue-50 p-4 border border-blue-100 mb-4">
                    <div className="flex items-start gap-3">
                      <Info className="h-5 w-5 text-blue-500 mt-0.5" />
                      <div>
                        <h3 className="font-medium text-blue-800 mb-1">Similar Plants You Might Like</h3>
                        <p className="text-sm text-blue-700">
                          These alternatives have similar characteristics to the Snake Plant but may better match
                          certain specific preferences.
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    {samplePlant.alternatives.map((alt, index) => (
                      <div key={index} className="rounded-lg border p-4 hover:shadow-sm transition-shadow">
                        <div className="flex justify-between items-start mb-2">
                          <h3 className="font-medium text-lg">{alt.name}</h3>
                          <Badge variant="outline" className="bg-green-50 text-green-700">
                            {alt.match_score}% Match
                          </Badge>
                        </div>
                        <p className="text-gray-600 mb-3">{alt.key_difference}</p>
                        <Button variant="outline" className="w-full" asChild>
                          <Link href="#">View Details</Link>
                        </Button>
                      </div>
                    ))}
                  </div>
                </TabsContent>
              </Tabs>

              <div className="flex justify-center pt-4">
                <Button className="bg-green-600 hover:bg-green-700">Add to My Plants</Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
