import { EnhancedFeatures } from "@/components/enhanced-features"
import { CallToAction } from "@/components/call-to-action"

export default function ToolsPage() {
  return (
    <main className="min-h-screen bg-gradient-to-b from-green-50 to-white">
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h1 className="text-4xl font-bold tracking-tight text-gray-900 sm:text-5xl">Advanced Plant Care Tools</h1>
            <p className="mt-4 text-xl text-gray-600 max-w-3xl mx-auto">
              Explore our suite of AI-powered tools designed to enhance your indoor gardening experience.
            </p>
          </div>
        </div>
      </section>

      <EnhancedFeatures />

      <CallToAction />
    </main>
  )
}
