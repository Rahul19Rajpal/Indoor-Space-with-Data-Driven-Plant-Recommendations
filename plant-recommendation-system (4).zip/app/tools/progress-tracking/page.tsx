"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { useToast } from "@/components/ui/use-toast"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Calendar, Camera, ArrowRight, Plus, Trash2 } from "lucide-react"
import { format } from "date-fns"

export default function ProgressTrackingPage() {
  const { toast } = useToast()
  const [isUploading, setIsUploading] = useState(false)
  const [selectedPlant, setSelectedPlant] = useState<string | null>(null)
  const [newPlantName, setNewPlantName] = useState("")

  // Sample plant data
  const [plants, setPlants] = useState([
    {
      id: "plant1",
      name: "Monstera Deliciosa",
      dateAdded: "2023-01-15",
      images: [
        {
          date: "2023-01-15",
          url: "https://images.unsplash.com/photo-1614594975525-e45190c55d0b?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
        },
        {
          date: "2023-02-15",
          url: "https://images.unsplash.com/photo-1622547748225-3fc4abd2cca0?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
        },
        {
          date: "2023-03-15",
          url: "https://images.unsplash.com/photo-1632321941439-97f69e8757c5?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
        },
      ],
    },
    {
      id: "plant2",
      name: "Fiddle Leaf Fig",
      dateAdded: "2023-02-10",
      images: [
        {
          date: "2023-02-10",
          url: "https://images.unsplash.com/photo-1616690710400-a16d146927c5?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
        },
        {
          date: "2023-03-10",
          url: "https://images.unsplash.com/photo-1620127682229-33388276e540?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
        },
      ],
    },
  ])

  const handleAddPlant = () => {
    if (!newPlantName.trim()) {
      toast({
        title: "Error",
        description: "Please enter a plant name",
        variant: "destructive",
      })
      return
    }

    const newPlant = {
      id: `plant${plants.length + 1}`,
      name: newPlantName,
      dateAdded: format(new Date(), "yyyy-MM-dd"),
      images: [],
    }

    setPlants([...plants, newPlant])
    setNewPlantName("")

    toast({
      title: "Plant added",
      description: `${newPlantName} has been added to your collection.`,
    })
  }

  const handleDeletePlant = (plantId: string) => {
    setPlants(plants.filter((plant) => plant.id !== plantId))
    if (selectedPlant === plantId) {
      setSelectedPlant(null)
    }

    toast({
      title: "Plant removed",
      description: "The plant has been removed from your collection.",
    })
  }

  const handleAddImage = (plantId: string) => {
    setIsUploading(true)

    // Simulate image upload
    setTimeout(() => {
      setPlants(
        plants.map((plant) => {
          if (plant.id === plantId) {
            return {
              ...plant,
              images: [
                ...plant.images,
                {
                  date: format(new Date(), "yyyy-MM-dd"),
                  url: "/placeholder.svg?height=300&width=300",
                },
              ],
            }
          }
          return plant
        }),
      )

      setIsUploading(false)

      toast({
        title: "Image added",
        description: "Your plant progress image has been added.",
      })
    }, 1500)
  }

  const selectedPlantData = plants.find((plant) => plant.id === selectedPlant)

  return (
    <div className="container mx-auto py-12 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <h1 className="text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl mb-4">Plant Progress Tracking</h1>
          <p className="text-lg text-gray-600">
            Track your plants' growth over time with photo documentation and create time-lapse visualizations.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="md:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle>My Plants</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex gap-2">
                  <Input
                    placeholder="Add new plant..."
                    value={newPlantName}
                    onChange={(e) => setNewPlantName(e.target.value)}
                  />
                  <Button onClick={handleAddPlant} size="icon" className="bg-green-600 hover:bg-green-700">
                    <Plus className="h-4 w-4" />
                  </Button>
                </div>

                <div className="space-y-2 mt-4">
                  {plants.map((plant) => (
                    <div
                      key={plant.id}
                      className={`flex items-center justify-between p-3 rounded-md cursor-pointer ${
                        selectedPlant === plant.id ? "bg-green-50 border border-green-200" : "hover:bg-gray-50"
                      }`}
                      onClick={() => setSelectedPlant(plant.id)}
                    >
                      <div className="flex items-center gap-3">
                        <div className="h-10 w-10 rounded-full bg-green-100 flex items-center justify-center">
                          <Camera className="h-5 w-5 text-green-600" />
                        </div>
                        <div>
                          <p className="font-medium">{plant.name}</p>
                          <p className="text-xs text-gray-500">
                            Added: {plant.dateAdded} • {plant.images.length} photos
                          </p>
                        </div>
                      </div>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={(e) => {
                          e.stopPropagation()
                          handleDeletePlant(plant.id)
                        }}
                      >
                        <Trash2 className="h-4 w-4 text-gray-400 hover:text-red-500" />
                      </Button>
                    </div>
                  ))}

                  {plants.length === 0 && (
                    <div className="text-center py-8 text-gray-500">
                      <p>No plants added yet.</p>
                      <p className="text-sm">Add your first plant to start tracking!</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="md:col-span-2">
            {selectedPlantData ? (
              <Card>
                <CardHeader>
                  <div className="flex justify-between items-center">
                    <CardTitle>{selectedPlantData.name}</CardTitle>
                    <Button
                      onClick={() => handleAddImage(selectedPlantData.id)}
                      disabled={isUploading}
                      className="bg-green-600 hover:bg-green-700"
                    >
                      {isUploading ? "Uploading..." : "Add New Photo"}
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <Tabs defaultValue="timeline" className="w-full">
                    <TabsList className="grid w-full grid-cols-2">
                      <TabsTrigger value="timeline">Timeline</TabsTrigger>
                      <TabsTrigger value="timelapse">Time-lapse</TabsTrigger>
                    </TabsList>
                    <TabsContent value="timeline" className="space-y-4 pt-4">
                      {selectedPlantData.images.length > 0 ? (
                        <div className="space-y-8">
                          {selectedPlantData.images.map((image, index) => (
                            <div key={index} className="relative">
                              <div className="flex items-center mb-2">
                                <Calendar className="h-4 w-4 text-gray-500 mr-2" />
                                <span className="text-sm font-medium">{image.date}</span>
                              </div>
                              <div className="rounded-lg overflow-hidden border">
                                <img
                                  src={image.url || "/placeholder.svg"}
                                  alt={`${selectedPlantData.name} on ${image.date}`}
                                  className="w-full h-auto"
                                />
                              </div>
                              {index < selectedPlantData.images.length - 1 && (
                                <div className="absolute left-1/2 -translate-x-1/2 -bottom-6 flex items-center justify-center h-8 w-8 rounded-full bg-gray-100">
                                  <ArrowRight className="h-4 w-4 text-gray-400 rotate-90" />
                                </div>
                              )}
                            </div>
                          ))}
                        </div>
                      ) : (
                        <div className="text-center py-12 text-gray-500">
                          <p>No photos added yet.</p>
                          <p className="text-sm">Add your first photo to start tracking progress!</p>
                        </div>
                      )}
                    </TabsContent>
                    <TabsContent value="timelapse" className="pt-4">
                      {selectedPlantData.images.length >= 2 ? (
                        <div className="space-y-4">
                          <div className="aspect-video rounded-lg overflow-hidden border bg-gray-100 flex items-center justify-center">
                            <div className="text-center">
                              <p className="text-gray-500 mb-2">Time-lapse Preview</p>
                              <Button className="bg-green-600 hover:bg-green-700">Generate Time-lapse</Button>
                            </div>
                          </div>
                          <div className="bg-gray-50 p-4 rounded-lg">
                            <h3 className="font-medium mb-2">Time-lapse Settings</h3>
                            <div className="grid grid-cols-2 gap-4">
                              <div>
                                <Label htmlFor="speed" className="text-sm">
                                  Speed (seconds per frame)
                                </Label>
                                <Input id="speed" type="number" min="0.1" max="5" step="0.1" defaultValue="1" />
                              </div>
                              <div>
                                <Label htmlFor="format" className="text-sm">
                                  Format
                                </Label>
                                <select
                                  id="format"
                                  className="w-full rounded-md border border-gray-300 shadow-sm px-3 py-2 focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
                                >
                                  <option>GIF</option>
                                  <option>MP4</option>
                                </select>
                              </div>
                            </div>
                          </div>
                        </div>
                      ) : (
                        <div className="text-center py-12 text-gray-500">
                          <p>At least 2 photos are needed to create a time-lapse.</p>
                          <p className="text-sm">Add more photos to enable this feature!</p>
                        </div>
                      )}
                    </TabsContent>
                  </Tabs>
                </CardContent>
              </Card>
            ) : (
              <Card className="h-full flex items-center justify-center">
                <CardContent className="text-center py-12">
                  <div className="mb-4">
                    <div className="h-24 w-24 rounded-full bg-green-100 mx-auto flex items-center justify-center">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="48"
                        height="48"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="text-green-600"
                      >
                        <path d="M12 2v8" />
                        <path d="M4.93 10.93 12 18" />
                        <path d="M19.07 10.93 12 18" />
                        <path d="M22 22H2" />
                        <path d="M12 18v4" />
                      </svg>
                    </div>
                  </div>
                  <h3 className="text-xl font-medium mb-2">Select a Plant to Track</h3>
                  <p className="text-gray-600 mb-6">
                    Choose a plant from your collection or add a new one to start tracking its growth progress.
                  </p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
