"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useToast } from "@/components/ui/use-toast"
import { Button } from "@/components/ui/button"

export default function TroubleshootPage() {
  const { toast } = useToast()
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [diagnosis, setDiagnosis] = useState<any>(null)
  const [formData, setFormData] = useState({
    plantType: "",
    symptoms: "",
    careHistory: "",
  })
  const [errors, setErrors] = useState({
    plantType: "",
    symptoms: "",
  })

  const validateForm = () => {
    const newErrors = {
      plantType: "",
      symptoms: "",
    }

    let isValid = true

    if (formData.plantType.length < 2) {
      newErrors.plantType = "Plant type must be at least 2 characters."
      isValid = false
    }

    if (formData.symptoms.length < 10) {
      newErrors.symptoms = "Please describe the symptoms in more detail (at least 10 characters)."
      isValid = false
    }

    setErrors(newErrors)
    return isValid
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (!validateForm()) {
      return
    }

    setIsSubmitting(true)

    // Simulate API call with timeout
    setTimeout(() => {
      // Hardcoded diagnosis responses based on plant type
      const diagnosisResponses: Record<string, any> = {
        monstera: {
          message:
            "Your Monstera appears to be suffering from overwatering. The yellowing leaves and brown spots are classic signs of this issue. Reduce watering frequency to once every 7-10 days, ensure the pot has proper drainage, and place the plant in bright, indirect light. Remove any severely damaged leaves with clean scissors.",
          recommendations: [
            "Allow soil to dry out completely between waterings",
            "Check for root rot and repot if necessary",
            "Increase air circulation around the plant",
            "Consider using a moisture meter to monitor soil dampness",
          ],
        },
        ficus: {
          message:
            "Your Ficus is likely experiencing stress from environmental changes. The leaf drop and yellowing are common responses to changes in light, temperature, or relocation. Ficus plants prefer consistency. Keep it in a stable environment with bright, indirect light and maintain consistent watering.",
          recommendations: [
            "Avoid moving the plant frequently",
            "Maintain consistent temperatures (65-75°F)",
            "Mist leaves occasionally to increase humidity",
            "Feed with a balanced liquid fertilizer during growing season",
          ],
        },
        "snake plant": {
          message:
            "Your Snake Plant appears to have root rot from overwatering. These plants are drought-tolerant and prefer to dry out completely between waterings. The soft, mushy base and yellowing leaves suggest too much moisture in the soil.",
          recommendations: [
            "Immediately remove the plant from wet soil",
            "Trim any mushy or damaged roots with sterilized scissors",
            "Repot in fresh, well-draining cactus or succulent soil",
            "Water only when soil is completely dry (every 3-4 weeks)",
          ],
        },
        pothos: {
          message:
            "Your Pothos is showing signs of underwatering with curling leaves and dry soil. Despite being hardy, these plants need regular moisture to thrive. The brown leaf tips and slow growth indicate the plant is stressed from lack of water.",
          recommendations: [
            "Water thoroughly until water runs out the drainage holes",
            "Maintain a regular watering schedule (when top inch of soil is dry)",
            "Consider placing in a location with higher humidity",
            "Check for root binding and repot if necessary",
          ],
        },
      }

      // Default diagnosis if plant type doesn't match predefined options
      let diagnosisResult = {
        message: `Based on your description of ${formData.plantType} with symptoms of "${formData.symptoms}", your plant appears to be suffering from a combination of watering issues and possible light stress. The yellowing leaves suggest either overwatering or underwatering, while the brown tips may indicate low humidity or excessive direct sunlight. First, check the soil moisture level - it should be slightly damp but not wet. Adjust your watering schedule accordingly and consider moving the plant to a location with bright, indirect light. Regular misting may help if humidity is an issue in your home.`,
        recommendations: [
          "Adjust watering frequency based on soil moisture",
          "Move to appropriate light conditions",
          "Consider humidity levels in the plant's environment",
          "Check for signs of pests or disease on the undersides of leaves",
        ],
      }

      // Look for matching plant types (case insensitive)
      const plantTypeLower = formData.plantType.toLowerCase()

      // Check if the entered plant type contains any of our known plant types
      for (const [key, value] of Object.entries(diagnosisResponses)) {
        if (plantTypeLower.includes(key)) {
          diagnosisResult = value
          break
        }
      }

      setDiagnosis(diagnosisResult)

      toast({
        title: "Diagnosis complete!",
        description: "We've analyzed your plant's symptoms.",
      })

      setIsSubmitting(false)
    }, 1500)
  }

  return (
    <div className="container mx-auto py-12 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <h1 className="text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl mb-4">
            Plant Care Troubleshooting
          </h1>
          <p className="text-lg text-gray-600">
            Describe your plant's symptoms and get AI-powered diagnosis and treatment recommendations.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="md:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle>How It Works</CardTitle>
              </CardHeader>
              <CardContent>
                <ol className="space-y-4">
                  <li className="flex items-start">
                    <span className="h-6 w-6 flex-shrink-0 text-gray-600">1.</span>
                    <span className="ml-4">Describe your plant's symptoms and type.</span>
                  </li>
                  <li className="flex items-start">
                    <span className="h-6 w-6 flex-shrink-0 text-gray-600">2.</span>
                    <span className="ml-4">Our AI analyzes the symptoms to provide a diagnosis.</span>
                  </li>
                  <li className="flex items-start">
                    <span className="h-6 w-6 flex-shrink-0 text-gray-600">3.</span>
                    <span className="ml-4">Receive personalized treatment recommendations.</span>
                  </li>
                </ol>
              </CardContent>
            </Card>
          </div>

          <div className="md:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle>Troubleshoot Your Plant</CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit}>
                  <div className="space-y-4">
                    <div>
                      <label htmlFor="plantType" className="block text-sm font-medium text-gray-700">
                        Plant Type
                      </label>
                      <div className="mt-1">
                        <input
                          type="text"
                          id="plantType"
                          name="plantType"
                          value={formData.plantType}
                          onChange={handleChange}
                          className="block w-full rounded-md border border-gray-300 shadow-sm px-3 py-2 focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
                          placeholder="Enter plant type (e.g., Monstera, Ficus, Snake Plant)"
                        />
                        {errors.plantType && <p className="mt-2 text-sm text-red-600">{errors.plantType}</p>}
                      </div>
                    </div>

                    <div>
                      <label htmlFor="symptoms" className="block text-sm font-medium text-gray-700">
                        Symptoms
                      </label>
                      <div className="mt-1">
                        <textarea
                          id="symptoms"
                          name="symptoms"
                          rows={4}
                          value={formData.symptoms}
                          onChange={handleChange}
                          className="block w-full rounded-md border border-gray-300 shadow-sm px-3 py-2 focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
                          placeholder="Describe the symptoms (e.g., yellowing leaves, brown spots, drooping)"
                        />
                        {errors.symptoms && <p className="mt-2 text-sm text-red-600">{errors.symptoms}</p>}
                      </div>
                    </div>

                    <div>
                      <label htmlFor="careHistory" className="block text-sm font-medium text-gray-700">
                        Care History (Optional)
                      </label>
                      <div className="mt-1">
                        <textarea
                          id="careHistory"
                          name="careHistory"
                          rows={4}
                          value={formData.careHistory}
                          onChange={handleChange}
                          className="block w-full rounded-md border border-gray-300 shadow-sm px-3 py-2 focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
                          placeholder="Describe any relevant care history (e.g., watering frequency, light conditions)"
                        />
                      </div>
                    </div>

                    <Button
                      type="submit"
                      disabled={isSubmitting}
                      className={`inline-flex w-full items-center rounded-md border border-transparent bg-green-600 px-4 py-2 text-base font-medium text-white shadow-sm hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2 sm:ml-3 sm:w-auto sm:text-sm ${
                        isSubmitting ? "opacity-50 cursor-not-allowed" : ""
                      }`}
                    >
                      {isSubmitting ? "Analyzing..." : "Get Diagnosis"}
                    </Button>
                  </div>
                </form>

                {diagnosis && (
                  <div className="mt-8 bg-green-50 p-4 rounded-md border border-green-200">
                    <h2 className="text-lg font-medium text-gray-900">Diagnosis and Recommendations</h2>
                    <p className="mt-2 text-sm text-gray-600">{diagnosis.message}</p>

                    {diagnosis.recommendations && (
                      <div className="mt-4">
                        <h3 className="font-medium text-gray-800">Recommended Actions:</h3>
                        <ul className="mt-2 pl-5 list-disc text-sm text-gray-600 space-y-1">
                          {diagnosis.recommendations.map((rec: string, index: number) => (
                            <li key={index}>{rec}</li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
