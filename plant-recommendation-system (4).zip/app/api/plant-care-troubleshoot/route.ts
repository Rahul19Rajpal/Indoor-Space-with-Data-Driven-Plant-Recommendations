import { type NextRequest, NextResponse } from "next/server"
import { generateText } from "ai"
import { openai } from "@ai-sdk/openai"

export async function POST(request: NextRequest) {
  try {
    const data = await request.json()
    const { symptoms, plantType, careHistory } = data

    // In a real implementation, this would use a more sophisticated AI model
    // For demo purposes, we'll use a simple prompt with OpenAI

    const prompt = `
    I need help diagnosing and treating a problem with my ${plantType || "indoor plant"}.
    
    Symptoms: ${symptoms}
    ${careHistory ? `Care history: ${careHistory}` : ""}
    
    Please provide:
    1. A diagnosis of the likely problem
    2. Treatment recommendations
    3. Prevention tips for the future
    `

    // Use AI SDK to generate a response
    const { text } = await generateText({
      model: openai("gpt-3.5-turbo"),
      prompt: prompt,
      system:
        "You are an expert botanist and plant pathologist specializing in indoor plants. Provide accurate, helpful advice for plant care problems.",
    })

    // Parse the response into structured data
    // In a real implementation, we would use a more structured approach
    const sections = text.split(/\d\.\s+/).filter(Boolean)

    return NextResponse.json({
      diagnosis: sections[0]?.trim() || "Could not determine a diagnosis based on the information provided.",
      treatment: sections[1]?.trim() || "Please provide more details about the symptoms for treatment recommendations.",
      prevention:
        sections[2]?.trim() || "Regular inspection and proper watering are key to preventing most plant issues.",
      fullResponse: text,
    })
  } catch (error) {
    console.error("Error troubleshooting plant care:", error)
    return NextResponse.json(
      {
        error: "Failed to process plant care troubleshooting",
        diagnosis: "We're experiencing technical difficulties. Please try again later.",
        treatment: "In the meantime, ensure your plant has appropriate light, water, and humidity levels.",
        prevention: "Regular inspection is key to catching plant problems early.",
      },
      { status: 500 },
    )
  }
}
