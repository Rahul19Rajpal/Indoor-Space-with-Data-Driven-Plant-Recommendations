import { NextResponse } from "next/server"
import fs from "fs/promises"
import path from "path"

export async function GET() {
  try {
    // Path to the CSV file
    const filePath = path.join(process.cwd(), "app/api/python/plant_123.csv")

    // Read the file
    const fileContent = await fs.readFile(filePath, "utf-8")

    // Return the file content
    return new NextResponse(fileContent, {
      headers: {
        "Content-Type": "text/csv",
        "Content-Disposition": "attachment; filename=plant_123.csv",
      },
    })
  } catch (error) {
    console.error("Error reading CSV file:", error)
    return NextResponse.json({ error: "Failed to read CSV file" }, { status: 500 })
  }
}
