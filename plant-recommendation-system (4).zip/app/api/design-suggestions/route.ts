import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const data = await request.json()
    const { room_type, plant_id } = data

    // In a real implementation, this would call the Python backend
    // to get design suggestions based on the plant and room type

    // For demo purposes, we'll return simulated results based on plant type
    let decor_suggestions = {
      pot_style: [
        "Terracotta pots with minimalist design",
        "Concrete geometric planters",
        "Small ceramic pots with drainage",
      ],
      color_scheme: [
        "Neutral tones with gold accents",
        "Black and white with green highlights",
        "Earth tones with terracotta accents",
      ],
      complementary_items: [
        "Natural fiber throw pillows",
        "Wooden or rattan furniture",
        "Botanical art prints",
        "Natural fiber rugs",
      ],
    }

    // Customize based on plant type
    if (plant_id === "monstera") {
      decor_suggestions = {
        pot_style: [
          "Large woven baskets",
          "Minimalist white ceramic planters",
          "Mid-century modern plant stands with simple pots",
        ],
        color_scheme: [
          "Tropical greens with natural wood tones",
          "Emerald and gold accents",
          "Jungle-inspired patterns with white backgrounds",
        ],
        complementary_items: [
          "Rattan or bamboo furniture",
          "Tropical print cushions or artwork",
          "Natural fiber rugs in neutral tones",
          "Hanging pendant lights with natural materials",
        ],
      }
    } else if (plant_id === "fiddle_leaf_fig") {
      decor_suggestions = {
        pot_style: [
          "Large modern ceramic planters",
          "Woven baskets with leather trim",
          "Elevated plant stands with simple pots",
        ],
        color_scheme: [
          "Deep greens with brass accents",
          "Neutral palette with textural elements",
          "Navy blue and white with green accents",
        ],
        complementary_items: [
          "Modern minimalist furniture",
          "Abstract art with organic shapes",
          "Textured throw blankets",
          "Statement floor lamps",
        ],
      }
    } else if (plant_id === "pothos") {
      decor_suggestions = {
        pot_style: [
          "Hanging planters with macramé",
          "Wall-mounted planters",
          "Colorful ceramic pots for trailing vines",
        ],
        color_scheme: ["Bohemian mix of jewel tones", "Earthy greens and browns", "Cream and gold with green accents"],
        complementary_items: [
          "Floating shelves for trailing plants",
          "Vintage-inspired mirrors",
          "Layered textiles with global patterns",
          "Mixed metal accents",
        ],
      }
    }

    // Customize based on room type
    if (room_type === "bedroom") {
      decor_suggestions.complementary_items = [
        "Linen bedding in earth tones",
        "Wooden bedside tables",
        "Soft ambient lighting",
        "Natural fiber curtains",
      ]
    } else if (room_type === "bathroom") {
      decor_suggestions.complementary_items = [
        "Wooden bath accessories",
        "Natural stone elements",
        "Glass containers for toiletries",
        "Bamboo bath mats",
      ]
    } else if (room_type === "kitchen") {
      decor_suggestions.complementary_items = [
        "Wooden cutting boards and utensils",
        "Herb drying racks",
        "Terracotta or ceramic containers",
        "Natural fiber dish towels",
      ]
    } else if (room_type === "office") {
      decor_suggestions.complementary_items = [
        "Wooden desk accessories",
        "Natural fiber desk organizers",
        "Botanical print stationery",
        "Adjustable task lighting",
      ]
    }

    return NextResponse.json({ decor_suggestions })
  } catch (error) {
    console.error("Error getting design suggestions:", error)
    return NextResponse.json({ error: "Failed to get design suggestions" }, { status: 500 })
  }
}
