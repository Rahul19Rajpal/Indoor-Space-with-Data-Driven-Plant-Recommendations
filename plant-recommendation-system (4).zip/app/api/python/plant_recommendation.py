import pandas as pd
import numpy as np
import json
import sys
import os
from datetime import datetime, timedelta
import matplotlib.pyplot as plt
import seaborn as sns
import io
import base64
from sklearn.metrics.pairwise import cosine_similarity

# Load the plant dataset
def load_plant_dataset():
    """Load plant dataset from the CSV file."""
    try:
        # Load the main plant dataset
        plant_df = pd.read_csv("plant_123.csv")
        print(f"Successfully loaded {len(plant_df)} plants from plant_123.csv")
        return plant_df
    except Exception as e:
        print(f"Error loading data: {e}")
        print("Falling back to sample data...")
        return create_sample_plant_data()

# Create sample data as fallback
def create_sample_plant_data():
    """Create sample plant dataset as fallback"""
    plant_data = {
        'plant_id': [f'P{i:03d}' for i in range(1, 21)],
        'common_name': [
            'Snake Plant', 'Peace Lily', 'Spider Plant', 'Pothos', 'Fiddle Leaf Fig',
            'ZZ Plant', 'Monstera', 'Rubber Plant', 'Aloe Vera', 'Chinese Evergreen',
            'Boston Fern', 'Jade Plant', 'English Ivy', 'Philodendron', 'African Violet',
            'Calathea', 'Dracaena', 'Ponytail Palm', 'Money Plant', 'Orchid'
        ],
        'family': [
            'Liliaceae', 'Araceae', 'Liliaceae', 'Araceae', 'Moraceae',
            'Araceae', 'Araceae', 'Moraceae', 'Liliaceae', 'Araceae',
            'Nephrolepidaceae', 'Crasssulaceae', 'Araliaceae', 'Araceae', 'Gesneriaceae',
            'Marantaceae', 'Liliaceae', 'Agavaceae', 'Piperaceae', 'Orchidaceae'
        ],
        'categories': [
            'Sansevieria', 'Spathiphyllum', 'Hanging', 'Hanging', 'Ficus',
            'Foliage plant', 'Philodendron', 'Ficus', 'Cactus & Succulent', 'Aglaonema',
            'Fern', 'Cactus & Succulent', 'Hanging', 'Philodendron', 'Flower',
            'Foliage plant', 'Dracaena', 'Foliage plant', 'Other', 'Flower'
        ],
        'origin': [
            'South Africa', 'Cultivar', 'Central Africa', 'South Pacific', 'Ouest Africa',
            'South Africa', 'Central America', 'Cultivar', 'Cultivar', 'Hybrid',
            'Cultivar', 'South Africa', 'Cultivar', 'Central America', 'Cultivar',
            'Brazil', 'Madagascar', 'Mexico', 'Venezuela', 'Hybrid'
        ],
        'climate': [
            'Tropical', 'Tropical', 'Tropical to subtropical', 'Tropical', 'Tropical',
            'Tropical', 'Tropical', 'Tropical', 'Tropical', 'Tropical',
            'Tropical', 'Subtropical arid', 'Subtropical', 'Tropical', 'Tropical',
            'Tropical', 'Tropical', 'Arid Tropical', 'Tropical', 'Tropical humid'
        ],
        'zone': [
            '[11,10]', '[11,10]', '[11, 9]', '[11,10]', '[11,10]',
            '[11,10]', '[11,10]', '[11,10]', '[11,10]', '[11]',
            '[11,10]', '[11, 8]', '[11, 8]', '[11,10]', '[11,11]',
            '[11]', '[11,10]', '[11,10]', '[11,11]', '[11,12]'
        ],
        'img_url': [
            'http://www.tropicopia.com/house-plant/thumbnails/5735.jpg',
            'http://www.tropicopia.com/house-plant/thumbnails/5758.jpg',
            'http://www.tropicopia.com/house-plant/thumbnails/5527.jpg',
            'http://www.tropicopia.com/house-plant/thumbnails/5594.jpg',
            'http://www.tropicopia.com/house-plant/thumbnails/5622.jpg',
            'http://www.tropicopia.com/house-plant/thumbnails/5789.jpg',
            'http://www.tropicopia.com/house-plant/thumbnails/5693.jpg',
            'http://www.tropicopia.com/house-plant/thumbnails/5618.jpg',
            'http://www.tropicopia.com/house-plant/thumbnails/5488.jpg',
            'http://www.tropicopia.com/house-plant/thumbnails/5466.jpg',
            'http://www.tropicopia.com/house-plant/thumbnails/5668.jpg',
            'http://www.tropicopia.com/house-plant/thumbnails/5536.jpg',
            'http://www.tropicopia.com/house-plant/thumbnails/5640.jpg',
            'http://www.tropicopia.com/house-plant/thumbnails/5690.jpg',
            'http://www.tropicopia.com/house-plant/thumbnails/5680.jpg',
            'http://www.tropicopia.com/house-plant/thumbnails/5504.jpg',
            'http://www.tropicopia.com/house-plant/thumbnails/5572.jpg',
            'http://www.tropicopia.com/house-plant/thumbnails/5670.jpg',
            'http://www.tropicopia.com/house-plant/thumbnails/5679.jpg',
            'http://www.tropicopia.com/house-plant/thumbnails/5681.jpg'
        ]
    }
    return pd.DataFrame(plant_data)

# Preprocess plant data
def preprocess_plant_data(plant_df):
    """Preprocess plant data to prepare for recommendation system"""
    # Create a copy to avoid modifying original
    df = plant_df.copy()
    
    # Add plant_id if not present
    if 'plant_id' not in df.columns:
        df['plant_id'] = [f'P{i:03d}' for i in range(1, len(df) + 1)]
    
    # Extract light requirements from climate and categories
    df['light_requirement'] = 'Medium'  # Default
    
    # Plants in 'Arid Tropical' climate typically need high light
    df.loc[df['climate'].str.contains('Arid', case=False, na=False), 'light_requirement'] = 'High'
    
    # Ferns, some Philodendrons, and plants with 'humid' in climate typically prefer lower light
    df.loc[df['categories'].str.contains('Fern', case=False, na=False), 'light_requirement'] = 'Low'
    df.loc[df['climate'].str.contains('humid', case=False, na=False), 'light_requirement'] = 'Low-Medium'
    
    # Cacti and succulents typically need high light
    df.loc[df['categories'].str.contains('Cactus|Succulent', case=False, na=False, regex=True), 'light_requirement'] = 'High'
    
    # Determine water frequency based on climate and categories
    df['water_frequency'] = 7  # Default weekly
    
    # Arid plants need less frequent watering
    df.loc[df['climate'].str.contains('Arid', case=False, na=False), 'water_frequency'] = 14
    
    # Tropical humid plants need more frequent watering
    df.loc[df['climate'].str.contains('humid', case=False, na=False), 'water_frequency'] = 5
    
    # Cacti and succulents need less frequent watering
    df.loc[df['categories'].str.contains('Cactus|Succulent', case=False, na=False, regex=True), 'water_frequency'] = 14
    
    # Determine humidity preference
    df['humidity_preference'] = 'Medium'  # Default
    
    # Plants from humid climates prefer high humidity
    df.loc[df['climate'].str.contains('humid', case=False, na=False), 'humidity_preference'] = 'High'
    
    # Arid plants prefer low humidity
    df.loc[df['climate'].str.contains('Arid', case=False, na=False), 'humidity_preference'] = 'Low'
    
    # Ferns typically prefer high humidity
    df.loc[df['categories'].str.contains('Fern', case=False, na=False), 'humidity_preference'] = 'High'
    
    # Determine maintenance difficulty
    df['maintenance_difficulty'] = 2  # Default moderate
    
    # Some plants are easier to care for
    easy_plants = ['Snake plant', 'ZZ plant', 'Pothos', 'Spider plant', 'Chinese Evergreen']
    for plant in easy_plants:
        df.loc[df['common_name'].str.contains(plant, case=False, na=False), 'maintenance_difficulty'] = 1
    
    # Some plants are more difficult
    difficult_plants = ['Calathea', 'Fiddle Leaf Fig', 'Orchid', 'Boston Fern']
    for plant in difficult_plants:
        df.loc[df['common_name'].str.contains(plant, case=False, na=False), 'maintenance_difficulty'] = 3
    
    # Convert maintenance to text
    df['care_difficulty'] = 'Moderate'
    df.loc[df['maintenance_difficulty'] == 1, 'care_difficulty'] = 'Easy'
    df.loc[df['maintenance_difficulty'] == 3, 'care_difficulty'] = 'Difficult'
    
    # Determine pet friendliness (this would need a proper database in real life)
    df['pet_friendly'] = False  # Default to not pet friendly
    
    # Some plants known to be pet friendly
    pet_friendly_plants = ['Spider plant', 'Boston Fern', 'Parlor palm', 'Areca palm', 'Money plant']
    for plant in pet_friendly_plants:
        df.loc[df['common_name'].str.contains(plant, case=False, na=False), 'pet_friendly'] = True
    
    # Determine suitable locations based on plant type
    df['suitable_locations'] = 'Living room'  # Default
    
    # Bathroom plants (high humidity lovers)
    df.loc[df['humidity_preference'] == 'High', 'suitable_locations'] = 'Bathroom, Living room'
    
    # Bedroom plants (typically air purifying and calming)
    bedroom_plants = ['Snake plant', 'Peace lily', 'Spider plant', 'Pothos', 'English ivy']
    for plant in bedroom_plants:
        df.loc[df['common_name'].str.contains(plant, case=False, na=False), 'suitable_locations'] = 'Bedroom, Living room'
    
    # Kitchen plants (herbs and air purifiers)
    kitchen_plants = ['Aloe', 'Herb', 'Spider plant']
    for plant in kitchen_plants:
        df.loc[df['common_name'].str.contains(plant, case=False, na=False), 'suitable_locations'] = 'Kitchen, Living room'
    
    # Office plants (low maintenance, air purifying)
    office_plants = ['Snake plant', 'ZZ plant', 'Pothos', 'Peace lily']
    for plant in office_plants:
        df.loc[df['common_name'].str.contains(plant, case=False, na=False), 'suitable_locations'] = 'Office, Living room'
    
    return df

class PlantRecommendationSystem:
    """Plant recommendation system that matches plants to rooms and user preferences."""

    def __init__(self, plant_data):
        """Initialize with plant data"""
        self.plant_data = plant_data
        print(f"Recommendation system initialized with {len(plant_data)} plants.")

    def calculate_match_score(self, plant, preferences):
        """
        Calculate a match score between a plant and user preferences.
        """
        score = 0
        total_weight = 0

        # Light preference matching
        if 'light_level' in preferences:
            weight = 3
            total_weight += weight

            user_light = preferences['light_level'].lower()
            plant_light = str(plant.get('light_requirement', 'Medium')).lower()

            # Simple matching logic based on light levels
            light_levels = {'low': 1, 'medium': 2, 'high': 3}
            
            # Map text descriptions to standardized levels
            mapped_plant_light = 'medium'  # Default
            for level in light_levels.keys():
                if level in plant_light:
                    mapped_plant_light = level
                    break
            
            # Handle medium-high or low-medium cases
            if 'medium-high' in plant_light or 'bright' in plant_light:
                mapped_plant_light = 'high'
            elif 'low-medium' in plant_light or 'partial' in plant_light:
                mapped_plant_light = 'medium'

            # Score based on how well the light levels match
            if mapped_plant_light == user_light:
                score += weight
            elif abs(light_levels.get(mapped_plant_light, 2) - light_levels.get(user_light, 2)) == 1:
                # Adjacent light levels get partial score
                score += weight * 0.5

        # Maintenance preference matching
        if 'maintenance' in preferences:
            weight = 2
            total_weight += weight

            user_maintenance = preferences['maintenance'].lower()
            plant_maintenance = str(plant.get('care_difficulty', 'Moderate')).lower()

            # Map various terms to standardized levels
            maint_map = {
                'low': ['easy', 'simple', 'beginner', 'low'],
                'medium': ['moderate', 'average', 'intermediate', 'medium'],
                'high': ['difficult', 'challenging', 'expert', 'high']
            }

            # Find standardized maintenance level
            mapped_plant_maint = 'medium'  # Default
            for level, terms in maint_map.items():
                if any(term in plant_maintenance for term in terms):
                    mapped_plant_maint = level
                    break

            # Score based on match
            if mapped_plant_maint == user_maintenance:
                score += weight
            elif abs(list(maint_map.keys()).index(mapped_plant_maint) -
                    list(maint_map.keys()).index(user_maintenance)) == 1:
                # Adjacent maintenance levels get partial score
                score += weight * 0.5

        # Pet safety preference
        if 'pet_safe' in preferences and preferences['pet_safe']:
            weight = 3
            total_weight += weight

            plant_pet_safe = plant.get('pet_friendly', False)
            if plant_pet_safe:
                score += weight

        # Room type matching
        if 'room_type' in preferences:
            weight = 2
            total_weight += weight

            user_room = preferences['room_type'].lower().replace('_', ' ')
            suitable_locations = str(plant.get('suitable_locations', 'Living room')).lower()

            # Map room types for matching
            room_map = {
                'living room': ['living', 'lounge', 'family'],
                'bedroom': ['bed', 'sleeping'],
                'bathroom': ['bath', 'wash', 'rest'],
                'kitchen': ['kitchen', 'cooking', 'dining'],
                'office': ['office', 'study', 'work']
            }

            # Find which standard room type the user's preference maps to
            user_room_category = user_room
            for room_type, terms in room_map.items():
                if any(term in user_room for term in terms):
                    user_room_category = room_type
                    break

            # Check if the room type is in suitable locations
            if any(term in suitable_locations for term in room_map.get(user_room_category, [user_room_category])):
                score += weight

        # Normalize score
        if total_weight > 0:
            return score / total_weight
        return 0

    def recommend_plants(self, preferences, top_n=5):
        """
        Recommend plants based on user preferences.

        Args:
            preferences (dict): User preferences for plant selection
            top_n (int): Number of top recommendations to return

        Returns:
            list: List of plant dictionaries with match scores
        """
        results = []

        for _, plant in self.plant_data.iterrows():
            plant_dict = plant.to_dict()
            score = self.calculate_match_score(plant_dict, preferences)
            plant_dict['match_score'] = score
            results.append(plant_dict)

        # Sort by score in descending order and take top_n
        results.sort(key=lambda x: x['match_score'], reverse=True)
        return results[:top_n]

    def diagnose_plant_issue(self, symptoms, plant_type=None):
        """
        Diagnose plant health issues based on symptoms.
        
        Args:
            symptoms (str): Description of plant symptoms
            plant_type (str, optional): Type of plant
            
        Returns:
            dict: Diagnosis and treatment recommendations
        """
        # This is a simplified version - in a real system, this would use a more sophisticated model
        symptoms_lower = symptoms.lower()
        
        # Common issues dictionary
        common_issues = {
            'yellow leaves': {
                'diagnosis': 'Overwatering or nutrient deficiency',
                'treatment': 'Check soil moisture and reduce watering frequency. Consider adding balanced fertilizer.',
                'prevention': 'Water only when the top inch of soil is dry. Use a regular fertilizing schedule.'
            },
            'brown leaves': {
                'diagnosis': 'Underwatering or low humidity',
                'treatment': 'Increase watering frequency and consider misting the plant or using a humidifier.',
                'prevention': 'Maintain a regular watering schedule and monitor humidity levels.'
            },
            'drooping': {
                'diagnosis': 'Underwatering or overwatering',
                'treatment': 'Check soil moisture. If dry, water thoroughly. If wet, allow to dry and check for root rot.',
                'prevention': 'Establish a consistent watering routine based on the plant\'s needs.'
            },
            'spots': {
                'diagnosis': 'Fungal infection or pest damage',
                'treatment': 'Isolate the plant. Remove affected leaves. Apply fungicide or insecticide as appropriate.',
                'prevention': 'Ensure good air circulation and avoid overhead watering.'
            },
            'wilting': {
                'diagnosis': 'Underwatering, overwatering, or temperature stress',
                'treatment': 'Check soil moisture and temperature conditions. Adjust watering and placement accordingly.',
                'prevention': 'Keep plant away from drafts, heaters, and air conditioners.'
            }
        }
        
        # Check for matching symptoms
        for symptom, info in common_issues.items():
            if symptom in symptoms_lower:
                return {
                    'symptom': symptom,
                    'diagnosis': info['diagnosis'],
                    'treatment': info['treatment'],
                    'prevention': info['prevention'],
                    'confidence': 0.8  # In a real system, this would be calculated
                }
        
        # If no specific match, provide general advice
        return {
            'symptom': 'general issue',
            'diagnosis': 'Multiple potential causes',
            'treatment': 'Monitor the plant closely. Check soil moisture, light conditions, and inspect for pests.',
            'prevention': 'Maintain regular care routine and research specific needs of your plant type.',
            'confidence': 0.5
        }

    def generate_arrangement(self, room_type, num_plants=3, style='modern'):
        """
        Generate a plant arrangement design based on room type and style.
        
        Args:
            room_type (str): Type of room
            num_plants (int): Number of plants to include
            style (str): Design style (modern, tropical, minimalist, etc.)
            
        Returns:
            dict: Arrangement design with plant recommendations
        """
        # Filter plants suitable for the room type
        room_type_lower = room_type.lower().replace('_', ' ')
        suitable_plants = []
        
        for _, plant in self.plant_data.iterrows():
            suitable_locations = str(plant.get('suitable_locations', '')).lower()
            if room_type_lower in suitable_locations:
                suitable_plants.append(plant.to_dict())
        
        # If not enough suitable plants, add some general ones
        if len(suitable_plants) < num_plants:
            for _, plant in self.plant_data.iterrows():
                if plant.to_dict() not in suitable_plants:
                    suitable_plants.append(plant.to_dict())
                    if len(suitable_plants) >= num_plants:
                        break
        
        # Select plants based on style
        selected_plants = []
        
        if style == 'modern':
            # Modern style prefers clean lines and architectural plants
            modern_categories = ['Sansevieria', 'Ficus', 'Dracaena', 'Foliage plant']
            for plant in suitable_plants:
                if any(cat in str(plant.get('categories', '')) for cat in modern_categories):
                    selected_plants.append(plant)
                    if len(selected_plants) >= num_plants:
                        break
        
        elif style == 'tropical':
            # Tropical style prefers lush, leafy plants
            tropical_categories = ['Palm', 'Philodendron', 'Monstera', 'Fern']
            for plant in suitable_plants:
                if any(cat in str(plant.get('categories', '')) for cat in tropical_categories):
                    selected_plants.append(plant)
                    if len(selected_plants) >= num_plants:
                        break
        
        elif style == 'minimalist':
            # Minimalist style prefers simple, low-maintenance plants
            minimalist_categories = ['Sansevieria', 'Cactus & Succulent', 'ZZ plant']
            for plant in suitable_plants:
                if any(cat in str(plant.get('categories', '')) or 'ZZ' in str(plant.get('common_name', '')) 
                       for cat in minimalist_categories):
                    selected_plants.append(plant)
                    if len(selected_plants) >= num_plants:
                        break
        
        # If we still don't have enough plants, add from the suitable plants
        while len(selected_plants) < num_plants and suitable_plants:
            for plant in suitable_plants:
                if plant not in selected_plants:
                    selected_plants.append(plant)
                    if len(selected_plants) >= num_plants:
                        break
        
        # Generate arrangement description
        arrangement_descriptions = {
            'modern': "A clean, architectural arrangement with bold shapes and minimal clutter.",
            'tropical': "A lush, vibrant arrangement that creates a jungle-like atmosphere.",
            'minimalist': "A simple, uncluttered arrangement with focus on negative space."
        }
        
        placement_suggestions = {
            'living_room': "Place larger plants in corners, medium plants on side tables, and smaller plants on shelves.",
            'bedroom': "Keep plants away from the bed. Place calming plants on dressers or nightstands.",
            'bathroom': "Place humidity-loving plants near the shower or bath. Use shelves and countertops for smaller plants.",
            'kitchen': "Use windowsills for herbs and small plants. Larger plants can go in corners or on top of cabinets.",
            'office': "Place air-purifying plants near your desk. Use shelves and filing cabinets for smaller plants."
        }
        
        return {
            'style': style,
            'description': arrangement_descriptions.get(style, "A beautiful plant arrangement for your space."),
            'placement': placement_suggestions.get(room_type, "Distribute plants throughout the room based on their light needs."),
            'plants': selected_plants
        }

    def detect_plant_disease(self, image_description):
        """
        Detect plant diseases from image description.
        In a real implementation, this would use computer vision.
        
        Args:
            image_description (str): Description of the plant image
            
        Returns:
            dict: Disease detection results
        """
        # This is a simplified version - in a real system, this would use image analysis
        description_lower = image_description.lower()
        
        # Common disease patterns
        diseases = {
            'powdery mildew': {
                'symptoms': 'white powdery spots on leaves',
                'treatment': 'Remove affected leaves. Apply fungicide. Improve air circulation.',
                'severity': 'moderate'
            },
            'leaf spot': {
                'symptoms': 'brown or black spots on leaves',
                'treatment': 'Remove affected leaves. Avoid overhead watering. Apply fungicide if severe.',
                'severity': 'moderate'
            },
            'root rot': {
                'symptoms': 'yellowing leaves, wilting, mushy stems',
                'treatment': 'Repot in fresh soil. Trim affected roots. Reduce watering frequency.',
                'severity': 'severe'
            },
            'spider mites': {
                'symptoms': 'fine webbing, stippled or yellow leaves',
                'treatment': 'Increase humidity. Spray with insecticidal soap or neem oil.',
                'severity': 'moderate'
            },
            'scale': {
                'symptoms': 'bumps on stems or leaves, sticky residue',
                'treatment': 'Remove with cotton swab dipped in alcohol. Apply insecticidal soap.',
                'severity': 'moderate'
            }
        }
        
        # Check for matching symptoms
        for disease, info in diseases.items():
            if info['symptoms'] in description_lower:
                return {
                    'disease': disease,
                    'symptoms': info['symptoms'],
                    'treatment': info['treatment'],
                    'severity': info['severity'],
                    'confidence': 0.75  # In a real system, this would be calculated
                }
        
        # If no specific match, provide general assessment
        return {
            'disease': 'unknown',
            'symptoms': 'unclear from description',
            'treatment': 'Monitor the plant closely. Consider consulting a plant specialist or providing clearer images.',
            'severity': 'unknown',
            'confidence': 0.3
        }

    def recommend_air_quality_plants(self, pollutants=None, room_size=None):
        """
        Recommend plants for improving air quality.
        
        Args:
            pollutants (list, optional): Specific pollutants to target
            room_size (str, optional): Size of the room (small, medium, large)
            
        Returns:
            list: Recommended plants for air purification
        """
        # Air-purifying plants and the pollutants they target
        air_purifying_plants = {
            'Peace Lily': ['benzene', 'formaldehyde', 'trichloroethylene', 'ammonia', 'xylene'],
            'Snake Plant': ['benzene', 'formaldehyde', 'trichloroethylene', 'xylene'],
            'Boston Fern': ['formaldehyde', 'xylene'],
            'Spider Plant': ['formaldehyde', 'xylene', 'carbon monoxide'],
            'Rubber Plant': ['formaldehyde'],
            'English Ivy': ['benzene', 'formaldehyde', 'xylene', 'toluene'],
            'Chinese Evergreen': ['benzene', 'formaldehyde'],
            'Bamboo Palm': ['benzene', 'formaldehyde', 'trichloroethylene'],
            'Dracaena': ['benzene', 'formaldehyde', 'trichloroethylene', 'xylene'],
            'Aloe Vera': ['formaldehyde', 'benzene']
        }
        
        # Find plants in our dataset that match the air-purifying plants
        air_quality_recommendations = []
        
        for _, plant in self.plant_data.iterrows():
            plant_name = str(plant.get('common_name', '')).strip()
            
            for purifying_plant, targeted_pollutants in air_purifying_plants.items():
                if purifying_plant.lower() in plant_name.lower():
                    plant_dict = plant.to_dict()
                    plant_dict['targeted_pollutants'] = targeted_pollutants
                    
                    # If specific pollutants are requested, check if this plant targets them
                    if pollutants:
                        if any(pollutant in targeted_pollutants for pollutant in pollutants):
                            air_quality_recommendations.append(plant_dict)
                    else:
                        air_quality_recommendations.append(plant_dict)
                    
                    break
        
        # Sort by number of pollutants targeted
        if pollutants:
            air_quality_recommendations.sort(
                key=lambda x: sum(1 for p in pollutants if p in x.get('targeted_pollutants', [])),
                reverse=True
            )
        else:
            air_quality_recommendations.sort(
                key=lambda x: len(x.get('targeted_pollutants', [])),
                reverse=True
            )
        
        # Adjust recommendations based on room size
        if room_size:
            if room_size.lower() == 'small':
                # For small rooms, recommend fewer and smaller plants
                small_plants = [p for p in air_quality_recommendations 
                               if 'Snake' in str(p.get('common_name', '')) or 
                                  'Aloe' in str(p.get('common_name', '')) or
                                  'Ivy' in str(p.get('common_name', ''))]
                if small_plants:
                    return small_plants[:3]
            
            elif room_size.lower() == 'large':
                # For large rooms, recommend more plants
                return air_quality_recommendations[:5]
        
        # Default return
        return air_quality_recommendations[:3]

    def explain_recommendation(self, plant):
        """
        Provide a detailed explanation for why a plant was recommended.
        
        Args:
            plant (dict): Plant information with match score
            
        Returns:
            dict: Explanation of the recommendation
        """
        explanation = {
            'overall_score': plant.get('match_score', 0),
            'factors': []
        }
        
        # Light requirements
        light_req = str(plant.get('light_requirement', 'Medium'))
        explanation['factors'].append({
            'factor': 'Light Requirements',
            'value': light_req,
            'explanation': f"This plant thrives in {light_req.lower()} light conditions."
        })
        
        # Maintenance level
        care = str(plant.get('care_difficulty', 'Moderate'))
        maintenance_explanations = {
            'Easy': "This plant is low-maintenance and forgiving, perfect for beginners or busy plant owners.",
            'Moderate': "This plant requires regular attention but is not overly demanding.",
            'Difficult': "This plant requires specific care and attention to thrive."
        }
        explanation['factors'].append({
            'factor': 'Maintenance Level',
            'value': care,
            'explanation': maintenance_explanations.get(care, "This plant has moderate care requirements.")
        })
        
        # Pet friendliness
        pet_friendly = plant.get('pet_friendly', False)
        explanation['factors'].append({
            'factor': 'Pet Safety',
            'value': 'Pet-friendly' if pet_friendly else 'Not pet-friendly',
            'explanation': "This plant is safe for households with pets." if pet_friendly else 
                          "This plant may be toxic to pets and should be kept out of their reach."
        })
        
        # Suitable locations
        locations = str(plant.get('suitable_locations', 'Living room'))
        explanation['factors'].append({
            'factor': 'Suitable Locations',
            'value': locations,
            'explanation': f"This plant is well-suited for placement in: {locations}."
        })
        
        # Climate adaptation
        climate = str(plant.get('climate', 'Tropical'))
        explanation['factors'].append({
            'factor': 'Natural Habitat',
            'value': climate,
            'explanation': f"This plant naturally grows in {climate.lower()} conditions."
        })
        
        return explanation

    def suggest_plant_recipes(self, plant_name):
        """
        Suggest recipes that use the specified edible plant.
        
        Args:
            plant_name (str): Name of the plant
            
        Returns:
            list: Recipe suggestions
        """
        # Dictionary of edible plants and their recipes
        plant_recipes = {
            'Aloe Vera': [
                {
                    'name': 'Aloe Vera Smoothie',
                    'ingredients': ['Aloe vera gel', 'Cucumber', 'Lime juice', 'Honey', 'Water'],
                    'instructions': 'Blend all ingredients until smooth. Serve chilled.',
                    'benefits': 'Hydrating and good for digestion.'
                },
                {
                    'name': 'Aloe Vera Face Mask',
                    'ingredients': ['Aloe vera gel', 'Honey', 'Lemon juice'],
                    'instructions': 'Mix ingredients and apply to face. Leave for 15 minutes, then rinse.',
                    'benefits': 'Soothes and moisturizes skin.'
                }
            ],
            'Mint': [
                {
                    'name': 'Fresh Mint Tea',
                    'ingredients': ['Fresh mint leaves', 'Hot water', 'Honey (optional)'],
                    'instructions': 'Steep mint leaves in hot water for 5 minutes. Add honey if desired.',
                    'benefits': 'Aids digestion and freshens breath.'
                },
                {
                    'name': 'Mint Pesto',
                    'ingredients': ['Fresh mint leaves', 'Garlic', 'Pine nuts', 'Parmesan cheese', 'Olive oil'],
                    'instructions': 'Blend all ingredients until smooth. Serve with pasta or as a spread.',
                    'benefits': 'Fresh flavor and aromatic.'
                }
            ],
            'Basil': [
                {
                    'name': 'Classic Basil Pesto',
                    'ingredients': ['Fresh basil leaves', 'Garlic', 'Pine nuts', 'Parmesan cheese', 'Olive oil'],
                    'instructions': 'Blend all ingredients until smooth. Serve with pasta.',
                    'benefits': 'Rich in antioxidants and flavor.'
                },
                {
                    'name': 'Tomato Basil Salad',
                    'ingredients': ['Fresh basil leaves', 'Tomatoes', 'Mozzarella', 'Olive oil', 'Balsamic vinegar'],
                    'instructions': 'Slice tomatoes and mozzarella. Arrange with basil leaves. Drizzle with oil and vinegar.',
                    'benefits': 'Light, refreshing, and nutritious.'
                }
            ],
            'Rosemary': [
                {
                    'name': 'Rosemary Roasted Potatoes',
                    'ingredients': ['Fresh rosemary', 'Potatoes', 'Olive oil', 'Garlic', 'Salt'],
                    'instructions': 'Toss potatoes with oil, rosemary, garlic, and salt. Roast until crispy.',
                    'benefits': 'Aromatic and flavorful side dish.'
                },
                {
                    'name': 'Rosemary Infused Olive Oil',
                    'ingredients': ['Fresh rosemary sprigs', 'Olive oil'],
                    'instructions': 'Heat oil with rosemary. Cool and strain. Store in a sealed container.',
                    'benefits': 'Adds flavor to many dishes.'
                }
            ],
            'Lavender': [
                {
                    'name': 'Lavender Lemonade',
                    'ingredients': ['Dried lavender', 'Lemon juice', 'Sugar', 'Water'],
                    'instructions': 'Make a lavender syrup. Mix with lemon juice and water. Serve over ice.',
                    'benefits': 'Calming and refreshing.'
                },
                {
                    'name': 'Lavender Shortbread Cookies',
                    'ingredients': ['Dried lavender', 'Butter', 'Sugar', 'Flour', 'Salt'],
                    'instructions': 'Mix ingredients. Roll out dough. Cut into shapes. Bake until golden.',
                    'benefits': 'Aromatic and delicious treat.'
                }
            ]
        }
        
        # Check if the plant is in our recipe database
        plant_name_lower = plant_name.lower()
        for edible_plant, recipes in plant_recipes.items():
            if edible_plant.lower() in plant_name_lower:
                return recipes
        
        # If no specific recipes found, check if it's a common herb
        common_herbs = ['mint', 'basil', 'rosemary', 'thyme', 'sage', 'oregano', 'cilantro', 'parsley']
        for herb in common_herbs:
            if herb in plant_name_lower:
                return [
                    {
                        'name': f'{herb.capitalize()} Garnish',
                        'ingredients': [f'Fresh {herb} leaves', 'Various dishes'],
                        'instructions': f'Chop {herb} leaves and sprinkle over dishes before serving.',
                        'benefits': 'Adds fresh flavor and visual appeal.'
                    },
                    {
                        'name': f'{herb.capitalize()} Infused Water',
                        'ingredients': [f'Fresh {herb} leaves', 'Water', 'Lemon or lime (optional)'],
                        'instructions': f'Add {herb} leaves to water. Let sit for at least 1 hour. Add citrus if desired.',
                        'benefits': 'Refreshing and hydrating.'
                    }
                ]
        
        # If not an edible plant
        return [
            {
                'name': 'Note',
                'ingredients': [],
                'instructions': f'The plant "{plant_name}" is not commonly used in culinary applications.',
                'benefits': 'This plant is primarily ornamental and not recommended for consumption.'
            }
        ]

    def suggest_decor(self, plant, room_type):
        """
        Suggest decor items that complement the plant.
        
        Args:
            plant (dict): Plant information
            room_type (str): Type of room
            
        Returns:
            dict: Decor suggestions
        """
        plant_name = str(plant.get('common_name', ''))
        categories = str(plant.get('categories', ''))
        
        # Base decor suggestions by plant type
        decor_suggestions = {
            'pot_style': [],
            'color_scheme': [],
            'complementary_items': []
        }
        
        # Pot style suggestions based on plant type
        if 'Cactus' in categories or 'Succulent' in categories:
            decor_suggestions['pot_style'] = [
                'Terracotta pots with minimalist design',
                'Concrete geometric planters',
                'Small ceramic pots with drainage'
            ]
        elif 'Palm' in categories:
            decor_suggestions['pot_style'] = [
                'Large woven baskets',
                'Tall ceramic planters',
                'Wooden plant stands with simple pots'
            ]
        elif 'Hanging' in categories:
            decor_suggestions['pot_style'] = [
                'Macramé plant hangers',
                'Hanging ceramic planters',
                'Glass terrariums with hanging options'
            ]
        elif 'Fern' in categories:
            decor_suggestions['pot_style'] = [
                'Glazed ceramic pots',
                'Hanging baskets with moisture retention',
                'Decorative plant stands with humidity trays'
            ]
        else:
            decor_suggestions['pot_style'] = [
                'Classic ceramic planters',
                'Modern minimalist pots',
                'Decorative containers that complement your decor'
            ]
        
        # Color scheme suggestions based on plant appearance
        if 'Snake' in plant_name or 'Sansevieria' in categories:
            decor_suggestions['color_scheme'] = [
                'Neutral tones with gold accents',
                'Black and white with green highlights',
                'Earth tones with terracotta accents'
            ]
        elif 'Ficus' in categories or 'Rubber' in plant_name:
            decor_suggestions['color_scheme'] = [
                'Deep greens with burgundy accents',
                'Monochromatic with textural elements',
                'Forest green with natural wood tones'
            ]
        elif 'Calathea' in plant_name or 'Maranta' in categories:
            decor_suggestions['color_scheme'] = [
                'Pink and green combinations',
                'Tropical patterns with white accents',
                'Jewel tones with metallic highlights'
            ]
        else:
            decor_suggestions['color_scheme'] = [
                'Natural greens with complementary earth tones',
                'Monochromatic scheme with textural variety',
                'Contrasting colors that highlight the plants natural hues'
            ]
        
        # Complementary items based on room type
        if 'living' in room_type.lower():
            decor_suggestions['complementary_items'] = [
                'Natural fiber throw pillows',
                'Wooden or rattan furniture',
                'Botanical art prints',
                'Natural fiber rugs'
            ]
        elif 'bed' in room_type.lower():
            decor_suggestions['complementary_items'] = [
                'Linen bedding in earth tones',
                'Wooden bedside tables',
                'Soft ambient lighting',
                'Natural fiber curtains'
            ]
        elif 'bath' in room_type.lower():
            decor_suggestions['complementary_items'] = [
                'Wooden bath accessories',
                'Natural stone elements',
                'Glass containers for toiletries',
                'Bamboo bath mats'
            ]
        elif 'kitchen' in room_type.lower():
            decor_suggestions['complementary_items'] = [
                'Wooden cutting boards and utensils',
                'Herb drying racks',
                'Terracotta or ceramic containers',
                'Natural fiber dish towels'
            ]
        elif 'office' in room_type.lower():
            decor_suggestions['complementary_items'] = [
                'Wooden desk accessories',
                'Natural fiber desk organizers',
                'Botanical print stationery',
                'Adjustable task lighting'
            ]
        
        return decor_suggestions

def visualize_plant_data(plant_df):
    """Create visualizations of plant data"""
    plt.figure(figsize=(15, 10))

    # Create visualizations based on available data
    # 1. Distribution of plant families
    plt.subplot(2, 2, 1)
    family_counts = plant_df['family'].value_counts().head(10)
    sns.barplot(x=family_counts.values, y=family_counts.index)
    plt.title('Top 10 Plant Families')
    plt.xlabel('Count')

    # 2. Distribution of plant categories
    plt.subplot(2, 2, 2)
    category_counts = plant_df['categories'].value_counts().head(10)
    sns.barplot(x=category_counts.values, y=category_counts.index)
    plt.title('Top 10 Plant Categories')
    plt.xlabel('Count')

    # 3. Distribution of plant origins
    plt.subplot(2, 2, 3)
    origin_counts = plant_df['origin'].value_counts().head(10)
    sns.barplot(x=origin_counts.values, y=origin_counts.index)
    plt.title('Top 10 Plant Origins')
    plt.xlabel('Count')

    # 4. Distribution of plant climates
    plt.subplot(2, 2, 4)
    climate_counts = plant_df['climate'].value_counts()
    sns.barplot(x=climate_counts.values, y=climate_counts.index)
    plt.title('Plant Climate Distribution')
    plt.xlabel('Count')

    plt.tight_layout()
    
    # Save to a bytes buffer
    buf = io.BytesIO()
    plt.savefig(buf, format='png')
    buf.seek(0)
    
    # Convert to base64 for embedding in HTML
    img_str = base64.b64encode(buf.read()).decode('utf-8')
    
    plt.close()
    
    return f"data:image/png;base64,{img_str}"

def process_request(request_data):
    """
    Process a request from the web application.
    
    Args:
        request_data (dict): Request data from the web application
        
    Returns:
        dict: Response data
    """
    try:
        request_type = request_data.get('request_type', 'recommend')
        
        # Load and preprocess plant data
        plant_df = load_plant_dataset()
        processed_df = preprocess_plant_data(plant_df)
        
        # Initialize recommendation system
        recommender = PlantRecommendationSystem(processed_df)
        
        if request_type == 'recommend':
            # Get plant recommendations
            preferences = request_data.get('preferences', {})
            recommendations = recommender.recommend_plants(preferences, top_n=5)
            
            # Add explanations for each recommendation
            for plant in recommendations:
                plant['explanation'] = recommender.explain_recommendation(plant)
            
            return {
                'success': True,
                'recommendations': recommendations
            }
        
        elif request_type == 'diagnose':
            # Diagnose plant health issues
            symptoms = request_data.get('symptoms', '')
            plant_type = request_data.get('plant_type', None)
            
            diagnosis = recommender.diagnose_plant_issue(symptoms, plant_type)
            
            return {
                'success': True,
                'diagnosis': diagnosis
            }
        
        elif request_type == 'arrangement':
            # Generate plant arrangement
            room_type = request_data.get('room_type', 'living_room')
            num_plants = request_data.get('num_plants', 3)
            style = request_data.get('style', 'modern')
            
            arrangement = recommender.generate_arrangement(room_type, num_plants, style)
            
            return {
                'success': True,
                'arrangement': arrangement
            }
        
        elif request_type == 'detect_disease':
            # Detect plant disease
            image_description = request_data.get('image_description', '')
            
            detection = recommender.detect_plant_disease(image_description)
            
            return {
                'success': True,
                'detection': detection
            }
        
        elif request_type == 'air_quality':
            # Recommend plants for air quality
            pollutants = request_data.get('pollutants', None)
            room_size = request_data.get('room_size', None)
            
            recommendations = recommender.recommend_air_quality_plants(pollutants, room_size)
            
            return {
                'success': True,
                'recommendations': recommendations
            }
        
        elif request_type == 'recipes':
            # Suggest plant-based recipes
            plant_name = request_data.get('plant_name', '')
            
            recipes = recommender.suggest_plant_recipes(plant_name)
            
            return {
                'success': True,
                'recipes': recipes
            }
        
        elif request_type == 'decor':
            # Suggest decor items
            plant_id = request_data.get('plant_id', '')
            room_type = request_data.get('room_type', 'living_room')
            
            # Find the plant in the dataset
            plant = None
            for _, row in processed_df.iterrows():
                if str(row.get('plant_id', '')) == plant_id:
                    plant = row.to_dict()
                    break
        
            if plant:
                decor_suggestions = recommender.suggest_decor(plant, room_type)
            
                return {
                    'success': True,
                    'decor_suggestions': decor_suggestions
                }
            else:
                return {
                    'success': False,
                    'error': 'Plant not found'
                }
        
        elif request_type == 'visualize':
            # Generate data visualizations
            visualization = visualize_plant_data(processed_df)
        
            return {
                'success': True,
                'visualization': visualization
            }
        
        else:
            return {
                'success': False,
                'error': f'Unknown request type: {request_type}'
            }
    except Exception as e:
        # Catch any exceptions and return an error response
        return {
            'success': False,
            'error': f'Error processing request: {str(e)}'
        }
def main():
    """Main function to handle command line requests"""
    try:
        # Check if running in a notebook environment (where sys.argv might include '-f')
        if len(sys.argv) > 1 and sys.argv[1] != '-f':
            input_file = sys.argv[1]
            output_file = sys.argv[2] if len(sys.argv) > 2 else 'response.json'
            
            try:
                # Load request data from input file
                with open(input_file, 'r') as f:
                    request_data = json.load(f)
                
                # Process the request
                response = process_request(request_data)
                
                # Write response to output file
                with open(output_file, 'w') as f:
                    json.dump(response, f, indent=2)
                
                print(f"Response written to {output_file}")
                
            except Exception as e:
                print(f"Error processing request: {e}")
                # Write error response to output file
                with open(output_file, 'w') as f:
                    json.dump({
                        'success': False,
                        'error': f"Error processing request: {str(e)}"
                    }, f, indent=2)
        else:
            # If no valid input file, run a demo
            print("Running demo recommendation...")
            
            # Load and preprocess plant data
            plant_df = load_plant_dataset()
            processed_df = preprocess_plant_data(plant_df)
            
            # Initialize recommendation system
            recommender = PlantRecommendationSystem(processed_df)
            
            # Example recommendation
            user_preferences = {
                'room_type': 'living_room',
                'light_level': 'medium',
                'maintenance': 'low',
                'pet_safe': True
            }
            
            recommendations = recommender.recommend_plants(user_preferences, top_n=5)
            
            print("\nTop 5 recommended plants based on user preferences:")
            for idx, plant in enumerate(recommendations, 1):
                plant_name = plant.get('common_name', f"Plant {plant.get('plant_id', '')}")
                score = plant.get('match_score', 0)
                
                print(f"{idx}. {plant_name} - Match Score: {score:.2f}")
            
            print("\nDemo completed!")
    except Exception as e:
        print(f"Error in main function: {e}")
        # If an output file was specified, write error response
        if len(sys.argv) > 2:
            output_file = sys.argv[2]
            try:
                with open(output_file, 'w') as f:
                    json.dump({
                        'success': False,
                        'error': f"Error in main function: {str(e)}"
                    }, f, indent=2)
            except:
                pass  # If we can't even write the error, there's not much we can do

if __name__ == "__main__":
    main()
