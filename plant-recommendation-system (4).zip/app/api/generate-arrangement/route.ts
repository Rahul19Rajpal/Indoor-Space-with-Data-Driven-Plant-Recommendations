import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const data = await request.json()
    const { roomType, style, numPlants } = data

    // In a real implementation, this would call the Python backend
    // to generate plant arrangement designs

    // For demo purposes, we'll return simulated results
    const arrangements = [
      {
        id: "arr001",
        name: "Tropical Oasis",
        description:
          "A lush arrangement featuring tall statement plants surrounded by medium and small plants for a layered effect.",
        plants: [
          { name: "Monstera Deliciosa", position: "back-center", size: "large" },
          { name: "Peace Lily", position: "middle-right", size: "medium" },
          { name: "Snake Plant", position: "back-left", size: "medium" },
          { name: "Pothos", position: "front-right", size: "small" },
          { name: "Calathea", position: "front-left", size: "small" },
        ],
        style: "tropical",
        careLevel: "moderate",
        lightRequirement: "medium",
        imageUrl:
          "https://images.unsplash.com/photo-1584589167171-541ce45f1eea?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80",
      },
      {
        id: "arr002",
        name: "Minimalist Zen",
        description: "A clean, simple arrangement with a focus on form and texture rather than quantity.",
        plants: [
          { name: "Fiddle Leaf Fig", position: "back-right", size: "large" },
          { name: "ZZ Plant", position: "middle-left", size: "medium" },
          { name: "Jade Plant", position: "front-center", size: "small" },
        ],
        style: "minimalist",
        careLevel: "easy",
        lightRequirement: "medium-high",
        imageUrl:
          "https://images.unsplash.com/photo-1602923668104-8f9e03e77e62?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80",
      },
      {
        id: "arr003",
        name: "Desert Harmony",
        description: "A striking arrangement of succulents and cacti with varying heights and textures.",
        plants: [
          { name: "Tall Cactus", position: "back-center", size: "large" },
          { name: "Aloe Vera", position: "middle-right", size: "medium" },
          { name: "Echeveria", position: "front-left", size: "small" },
          { name: "String of Pearls", position: "front-right", size: "small" },
          { name: "Haworthia", position: "middle-left", size: "small" },
        ],
        style: "desert",
        careLevel: "easy",
        lightRequirement: "high",
        imageUrl:
          "https://images.unsplash.com/photo-1509423350716-97f9360b4e09?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80",
      },
    ]

    // Filter arrangements based on user preferences
    let filteredArrangements = [...arrangements]

    if (style) {
      filteredArrangements = filteredArrangements.filter((arr) => arr.style === style)
    }

    // If no arrangements match the style, return the first one
    if (filteredArrangements.length === 0) {
      filteredArrangements = [arrangements[0]]
    }

    // Adjust number of plants if needed
    if (numPlants && filteredArrangements[0]) {
      const arrangement = { ...filteredArrangements[0] }

      // Adjust plants array based on requested number
      if (numPlants < arrangement.plants.length) {
        arrangement.plants = arrangement.plants.slice(0, numPlants)
      } else if (numPlants > arrangement.plants.length) {
        // Add more plants if needed
        const additionalPlants = [
          { name: "Spider Plant", position: "middle-center", size: "small" },
          { name: "Rubber Plant", position: "back-left", size: "medium" },
          { name: "Boston Fern", position: "front-right", size: "medium" },
          { name: "Chinese Evergreen", position: "front-left", size: "small" },
        ]

        for (
          let i = arrangement.plants.length;
          i < numPlants && i < arrangement.plants.length + additionalPlants.length;
          i++
        ) {
          arrangement.plants.push(additionalPlants[i - arrangement.plants.length])
        }
      }

      filteredArrangements[0] = arrangement
    }

    return NextResponse.json({
      arrangements: filteredArrangements,
      recommendedArrangement: filteredArrangements[0],
      designTips: [
        "Group plants of varying heights for visual interest",
        "Consider the mature size of plants when arranging",
        "Use containers that complement your interior design style",
        "Create focal points with statement plants",
        "Ensure all plants have similar light and care requirements",
      ],
    })
  } catch (error) {
    console.error("Error generating plant arrangement:", error)
    return NextResponse.json({ error: "Failed to generate plant arrangement" }, { status: 500 })
  }
}
