import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const data = await request.json()
    const { plant_name } = data

    // In a real implementation, this would call the Python backend
    // to get recipes based on the plant name

    // For demo purposes, we'll return simulated results based on plant type
    const plantRecipes: Record<string, any[]> = {
      Mint: [
        {
          name: "Fresh Mint Tea",
          ingredients: ["Fresh mint leaves", "Hot water", "Honey (optional)"],
          instructions: "Steep mint leaves in hot water for 5 minutes. Add honey if desired.",
          benefits: "Aids digestion and freshens breath",
          imageUrl:
            "https://images.unsplash.com/photo-1576092768241-dec231879fc3?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
        },
        {
          name: "Mint Pesto",
          ingredients: ["Fresh mint leaves", "Garlic", "Pine nuts", "Parmesan cheese", "Olive oil"],
          instructions: "Blend all ingredients until smooth. Serve with pasta or as a spread.",
          benefits: "Fresh flavor and aromatic",
          imageUrl:
            "https://images.unsplash.com/photo-1600335895229-6e75511892c8?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
        },
        {
          name: "Mint Infused Water",
          ingredients: ["Fresh mint leaves", "Water", "Lemon or lime (optional)"],
          instructions: "Add mint leaves to water. Let sit for at least 1 hour. Add citrus if desired.",
          benefits: "Refreshing and hydrating",
          imageUrl:
            "https://images.unsplash.com/photo-1595475207225-428b62bda831?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
        },
      ],
      Basil: [
        {
          name: "Classic Basil Pesto",
          ingredients: ["Fresh basil leaves", "Garlic", "Pine nuts", "Parmesan cheese", "Olive oil"],
          instructions: "Blend all ingredients until smooth. Serve with pasta.",
          benefits: "Rich in antioxidants and flavor",
        },
        {
          name: "Tomato Basil Salad",
          ingredients: ["Fresh basil leaves", "Tomatoes", "Mozzarella", "Olive oil", "Balsamic vinegar"],
          instructions: "Slice tomatoes and mozzarella. Arrange with basil leaves. Drizzle with oil and vinegar.",
          benefits: "Light, refreshing, and nutritious",
        },
        {
          name: "Basil Lemonade",
          ingredients: ["Fresh basil leaves", "Lemon juice", "Sugar", "Water", "Ice"],
          instructions: "Muddle basil with sugar. Add lemon juice and water. Strain and serve over ice.",
          benefits: "Refreshing summer drink",
        },
      ],
      Rosemary: [
        {
          name: "Rosemary Roasted Potatoes",
          ingredients: ["Fresh rosemary", "Potatoes", "Olive oil", "Garlic", "Salt"],
          instructions: "Toss potatoes with oil, rosemary, garlic, and salt. Roast until crispy.",
          benefits: "Aromatic and flavorful side dish",
        },
        {
          name: "Rosemary Infused Olive Oil",
          ingredients: ["Fresh rosemary sprigs", "Olive oil"],
          instructions: "Heat oil with rosemary. Cool and strain. Store in a sealed container.",
          benefits: "Adds flavor to many dishes",
        },
        {
          name: "Rosemary Focaccia",
          ingredients: ["Fresh rosemary", "Flour", "Yeast", "Olive oil", "Salt"],
          instructions: "Make focaccia dough. Top with rosemary and salt before baking.",
          benefits: "Aromatic bread with herbal benefits",
        },
      ],
      "Aloe Vera": [
        {
          name: "Aloe Vera Smoothie",
          ingredients: ["Aloe vera gel", "Cucumber", "Lime juice", "Honey", "Water"],
          instructions: "Blend all ingredients until smooth. Serve chilled.",
          benefits: "Hydrating and good for digestion",
        },
        {
          name: "Aloe Vera Face Mask",
          ingredients: ["Aloe vera gel", "Honey", "Lemon juice"],
          instructions: "Mix ingredients and apply to face. Leave for 15 minutes, then rinse.",
          benefits: "Soothes and moisturizes skin",
        },
        {
          name: "Aloe Vera Juice",
          ingredients: ["Aloe vera gel", "Water", "Lemon juice", "Honey"],
          instructions: "Blend aloe gel with water. Add lemon and honey to taste. Strain if needed.",
          benefits: "Supports digestive health",
        },
      ],
    }

    // Find recipes for the requested plant
    let recipes: any[] = []

    // Check for exact matches
    if (plantRecipes[plant_name]) {
      recipes = plantRecipes[plant_name]
    } else {
      // Check for partial matches
      for (const [key, value] of Object.entries(plantRecipes)) {
        if (
          plant_name.toLowerCase().includes(key.toLowerCase()) ||
          key.toLowerCase().includes(plant_name.toLowerCase())
        ) {
          recipes = value
          break
        }
      }
    }

    // If no recipes found, return a default message
    if (recipes.length === 0) {
      recipes = [
        {
          name: "Note",
          ingredients: [],
          instructions: `The plant "${plant_name}" is not commonly used in culinary applications.`,
          benefits: "This plant is primarily ornamental and not recommended for consumption.",
        },
      ]
    }

    return NextResponse.json({ recipes })
  } catch (error) {
    console.error("Error getting plant recipes:", error)
    return NextResponse.json({ error: "Failed to get plant recipes" }, { status: 500 })
  }
}
