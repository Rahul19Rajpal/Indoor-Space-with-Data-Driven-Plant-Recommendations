import { type NextRequest, NextResponse } from "next/server"
import { exec } from "child_process"
import { promisify } from "util"
import fs from "fs/promises"
import path from "path"
import { v4 as uuidv4 } from "uuid"

// Convert exec to Promise-based
const execPromise = promisify(exec)

export async function POST(request: NextRequest) {
  try {
    const data = await request.json()

    // Create a unique ID for this request
    const requestId = uuidv4()
    const inputFile = `/tmp/input_${requestId}.json`
    const outputFile = `/tmp/output_${requestId}.json`

    // Write the input data to a temporary file
    await fs.writeFile(inputFile, JSON.stringify(data))

    // Execute the Python script
    const pythonScript = path.join(process.cwd(), "app/api/python/plant_recommendation.py")
    const { stdout, stderr } = await execPromise(`python ${pythonScript} ${inputFile} ${outputFile}`)

    // Check if the script executed successfully
    if (stderr) {
      console.error("Python script error:", stderr)
      return NextResponse.json({ error: "Failed to execute Python script", details: stderr }, { status: 500 })
    }

    // Read the output file
    const outputData = await fs.readFile(outputFile, "utf-8")
    const results = JSON.parse(outputData)

    // Clean up temporary files
    await Promise.all([fs.unlink(inputFile).catch(() => {}), fs.unlink(outputFile).catch(() => {})])

    return NextResponse.json(results)
  } catch (error) {
    console.error("Error executing Python script:", error)
    return NextResponse.json({ error: "Failed to process request" }, { status: 500 })
  }
}
