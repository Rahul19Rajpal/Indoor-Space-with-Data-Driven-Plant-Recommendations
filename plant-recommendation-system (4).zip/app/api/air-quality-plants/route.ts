import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const data = await request.json()
    const { roomSize, pollutants } = data

    // Add more plant options
    const allPlants = [
      {
        plant_id: "P001",
        common_name: "Peace Lily",
        family: "Araceae",
        categories: "Spathiphyllum",
        img_url:
          "https://images.unsplash.com/photo-1616692659287-b4c79d9b8d09?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
        light_requirement: "Medium",
        care_difficulty: "Moderate",
        pet_friendly: false,
        targeted_pollutants: ["benzene", "formaldehyde", "trichloroethylene", "ammonia", "xylene"],
      },
      {
        plant_id: "P002",
        common_name: "Snake Plant",
        family: "Liliaceae",
        categories: "Sansevieria",
        img_url:
          "https://images.unsplash.com/photo-1593482892290-f54927ae2b7a?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
        light_requirement: "Low",
        care_difficulty: "Easy",
        pet_friendly: false,
        targeted_pollutants: ["benzene", "formaldehyde", "trichloroethylene", "xylene"],
      },
      {
        plant_id: "P003",
        common_name: "Spider Plant",
        family: "Liliaceae",
        categories: "Hanging",
        img_url:
          "https://images.unsplash.com/photo-1572688484438-313a6e50c333?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
        light_requirement: "Medium",
        care_difficulty: "Easy",
        pet_friendly: true,
        targeted_pollutants: ["formaldehyde", "xylene", "carbon monoxide"],
      },
      {
        plant_id: "P004",
        common_name: "Boston Fern",
        family: "Nephrolepidaceae",
        categories: "Fern",
        img_url:
          "https://images.unsplash.com/photo-1614594604854-562f9d3e1e67?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
        light_requirement: "Medium",
        care_difficulty: "Moderate",
        pet_friendly: true,
        targeted_pollutants: ["formaldehyde", "xylene"],
      },
      {
        plant_id: "P005",
        common_name: "Aloe Vera",
        family: "Asphodelaceae",
        categories: "Succulent",
        img_url:
          "https://images.unsplash.com/photo-1596547609652-9cf5d8c6a5f6?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
        light_requirement: "High",
        care_difficulty: "Easy",
        pet_friendly: false,
        targeted_pollutants: ["formaldehyde", "benzene"],
      },
      {
        plant_id: "P006",
        common_name: "English Ivy",
        family: "Araliaceae",
        categories: "Hanging",
        img_url:
          "https://images.unsplash.com/photo-1591454371758-644f9d123a81?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
        light_requirement: "Medium",
        care_difficulty: "Moderate",
        pet_friendly: false,
        targeted_pollutants: ["benzene", "formaldehyde", "xylene", "toluene"],
      },
    ]

    // Shuffle the plants array
    const shuffledPlants = [...allPlants].sort(() => 0.5 - Math.random())

    // Select a subset based on the request
    const recommendations = shuffledPlants.slice(0, 3)

    // Filter by pollutants if specified
    let filteredRecommendations = [...recommendations]
    if (pollutants && pollutants.length > 0) {
      filteredRecommendations = filteredRecommendations.filter((plant) =>
        pollutants.some((p: string) => plant.targeted_pollutants.includes(p)),
      )

      // Sort by number of matching pollutants
      filteredRecommendations.sort((a, b) => {
        const aMatches = pollutants.filter((p: string) => a.targeted_pollutants.includes(p)).length
        const bMatches = pollutants.filter((p: string) => b.targeted_pollutants.includes(p)).length
        return bMatches - aMatches
      })
    }

    // Adjust for room size
    if (roomSize === "small") {
      filteredRecommendations = filteredRecommendations.slice(0, 2)
    } else if (roomSize === "large") {
      // Add more plants for large rooms
      filteredRecommendations.push({
        plant_id: "P004",
        common_name: "Boston Fern",
        family: "Nephrolepidaceae",
        categories: "Fern",
        img_url:
          "https://images.unsplash.com/photo-1614594604854-562f9d3e1e67?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
        light_requirement: "Medium",
        care_difficulty: "Moderate",
        pet_friendly: true,
        targeted_pollutants: ["formaldehyde", "xylene"],
      })
    }

    return NextResponse.json({ recommendations: filteredRecommendations })
  } catch (error) {
    console.error("Error getting air quality plant recommendations:", error)
    return NextResponse.json({ error: "Failed to get air quality plant recommendations" }, { status: 500 })
  }
}
