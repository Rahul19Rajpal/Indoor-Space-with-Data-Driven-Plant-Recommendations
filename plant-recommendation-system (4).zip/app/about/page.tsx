import Link from "next/link"
import { Button } from "@/components/ui/button"

export default function AboutPage() {
  return (
    <main className="min-h-screen bg-gradient-to-b from-green-50 to-white py-12">
      <div className="container mx-auto px-4">
        <div className="mb-12 text-center">
          <h1 className="text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl">About PlantWise</h1>
          <p className="mt-4 text-lg text-gray-600">
            Enhancing indoor plant arrangements using data science and machine learning.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center mb-16">
          <div>
            <h2 className="text-2xl font-bold mb-4">Our Mission</h2>
            <p className="text-gray-700 mb-4">
              PlantWise aims to revolutionize indoor plant care by leveraging data science and machine learning to
              provide personalized recommendations and care schedules.
            </p>
            <p className="text-gray-700 mb-4">
              Our system addresses the limitations of conventional approaches by considering multiple parameters
              including room dimensions, light conditions, humidity levels, and user preferences to optimize plant
              selection and arrangement.
            </p>
            <p className="text-gray-700">
              We believe that everyone deserves to experience the benefits of indoor plants, regardless of their
              gardening experience or knowledge.
            </p>
          </div>
          <div className="rounded-lg overflow-hidden shadow-xl" style={{ width: "500px", height: "350px" }}>
            <img
              src="https://images.unsplash.com/photo-1545241047-6083a3684587?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80"
              alt="Indoor plants arrangement"
              className="object-cover w-full h-full"
            />
          </div>
        </div>

        <div className="mb-16">
          <h2 className="text-2xl font-bold mb-6 text-center">Our Approach</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <h3 className="text-xl font-semibold mb-3">Data-Driven</h3>
              <p className="text-gray-700">
                We collect and analyze comprehensive data on plant requirements, environmental conditions, and user
                feedback to provide accurate recommendations.
              </p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <h3 className="text-xl font-semibold mb-3">Personalized</h3>
              <p className="text-gray-700">
                Our system learns from user interactions and adapts recommendations based on individual preferences and
                environmental conditions.
              </p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <h3 className="text-xl font-semibold mb-3">Comprehensive</h3>
              <p className="text-gray-700">
                We consider multiple factors including light, humidity, temperature, maintenance requirements, and
                aesthetic preferences.
              </p>
            </div>
          </div>
        </div>

        <div className="mb-16">
          <h2 className="text-2xl font-bold mb-6 text-center">The Team</h2>
          <div className="flex justify-center">
            <div className="bg-white p-6 rounded-lg shadow-sm text-center max-w-md">
              <div className="w-24 h-24 rounded-full overflow-hidden mx-auto mb-4">
                
              </div>
              <h3 className="text-xl font-semibold">Rahul Rajpal</h3>
              <p className="text-gray-700 text-sm">
                Designed the whole core recommendation algorithm and hybrid model architecture for plant selection and care
                optimization and website.
              </p>
            </div>
          </div>
        </div>

        <div className="text-center">
          <Button asChild size="lg" className="bg-green-600 hover:bg-green-700">
            <Link href="/">Get Started</Link>
          </Button>
        </div>
      </div>
    </main>
  )
}
