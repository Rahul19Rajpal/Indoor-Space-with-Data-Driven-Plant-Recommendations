import { HeroSection } from "@/components/hero-section"
import { Features } from "@/components/features"
import { PlantRecommendationForm } from "@/components/plant-recommendation-form"
import { PlantDashboard } from "@/components/plant-dashboard"
import { EnhancedFeatures } from "@/components/enhanced-features"
import { CallToAction } from "@/components/call-to-action"

export default function Home() {
  return (
    <main className="min-h-screen bg-gradient-to-b from-green-50 to-white">
      <HeroSection />
      <Features />
      <section id="recommendation" className="container mx-auto px-4 py-12">
        <div className="mb-12 text-center">
          <h2 className="text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl">
            Find Your Perfect Indoor Plants
          </h2>
          <p className="mt-4 text-lg text-gray-600">
            Tell us about your space and preferences, and we'll recommend the best plants for you.
          </p>
        </div>
        <PlantRecommendationForm />
      </section>
      <section id="dashboard" className="container mx-auto px-4 py-12 bg-white rounded-lg shadow-sm">
        <PlantDashboard />
      </section>
      <EnhancedFeatures />
      <CallToAction />
    </main>
  )
}
