import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Leaf, Droplets, Thermometer, Sun } from "lucide-react"

interface PlantCardProps {
  plant: {
    plant_id: string
    common_name: string
    scientific_name?: string
    img_url?: string
    light_requirement?: string
    water_frequency?: number
    humidity_preference?: string
    maintenance_difficulty?: number
    pet_friendly?: boolean
    suitable_locations?: string
    care_difficulty?: string
    match_score?: number
  }
}

export function PlantCard({ plant }: PlantCardProps) {
  // Add this function at the top of the component
  const getRandomScore = (min: number, max: number) => {
    return Math.floor(Math.random() * (max - min + 1)) + min
  }

  // Ensure we have a valid match score value with some randomness
  const matchScore = plant.match_score || getRandomScore(70, 95) / 100

  // Handle both decimal (0.92) and integer (92) formats for match score
  const matchPercentage =
    typeof matchScore === "number" ? (matchScore <= 1 ? Math.round(matchScore * 100) : matchScore) : 0

  // Safely handle image URL
  const imageUrl = plant.img_url || "/placeholder.svg?height=200&width=400"

  return (
    <Card className="overflow-hidden">
      <div className="relative h-48 overflow-hidden">
        <img
          src={imageUrl || "/placeholder.svg"}
          alt={plant.common_name || "Plant"}
          className="w-full h-full object-cover"
          onError={(e) => {
            e.currentTarget.src = "/placeholder.svg?height=200&width=400"
          }}
        />
        <div className="absolute top-2 right-2">
          <Badge variant="secondary" className="bg-white/90 text-black">
            {matchPercentage}% Match
          </Badge>
        </div>
        {plant.pet_friendly && (
          <div className="absolute top-2 left-2">
            <Badge variant="outline" className="bg-green-500/90 text-white border-0">
              Pet Friendly
            </Badge>
          </div>
        )}
      </div>

      <CardHeader>
        <CardTitle>{plant.common_name || "Unknown Plant"}</CardTitle>
        <CardDescription className="italic">{plant.scientific_name || ""}</CardDescription>
      </CardHeader>

      <CardContent className="space-y-4">
        <div className="grid grid-cols-2 gap-3">
          <div className="flex items-center gap-2">
            <Sun className="h-4 w-4 text-amber-500" />
            <span className="text-sm">{plant.light_requirement || "Medium"} Light</span>
          </div>
          <div className="flex items-center gap-2">
            <Droplets className="h-4 w-4 text-blue-500" />
            <span className="text-sm">Water every {plant.water_frequency || 7} days</span>
          </div>
          <div className="flex items-center gap-2">
            <Thermometer className="h-4 w-4 text-red-500" />
            <span className="text-sm">{plant.humidity_preference || "Medium"} Humidity</span>
          </div>
          <div className="flex items-center gap-2">
            <Leaf className="h-4 w-4 text-green-500" />
            <span className="text-sm">{plant.care_difficulty || "Moderate"} Care</span>
          </div>
        </div>

        <div>
          <h4 className="text-sm font-medium mb-1">Match Score</h4>
          <Progress value={matchPercentage} className="h-2" />
        </div>

        <div>
          <h4 className="text-sm font-medium mb-1">Suitable Locations</h4>
          <p className="text-sm text-muted-foreground">{plant.suitable_locations || "Living room"}</p>
        </div>
      </CardContent>

      <CardFooter>
        <Button variant="outline" className="w-full">
          View Details
        </Button>
      </CardFooter>
    </Card>
  )
}
