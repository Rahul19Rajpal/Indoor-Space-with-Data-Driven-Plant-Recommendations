import { Button } from "@/components/ui/button"
import Link from "next/link"

export function CallToAction() {
  return (
    <section className="py-16 bg-green-600 text-white">
      <div className="container mx-auto px-4 text-center">
        <h2 className="text-3xl font-bold mb-4">Ready to transform your indoor space?</h2>
        <p className="text-lg mb-8 max-w-2xl mx-auto">
          Join thousands of plant enthusiasts who have discovered the perfect plants for their homes using our
          data-driven recommendations.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button
            asChild
            size="lg"
            variant="outline"
            className="bg-white text-green-600 hover:bg-gray-100 border-white"
          >
            <Link href="#recommendation">Get Plant Recommendations</Link>
          </Button>
          <Button asChild size="lg" className="bg-green-700 hover:bg-green-800 border-green-700">
            <Link href="/signup">Create Free Account</Link>
          </Button>
        </div>
      </div>
    </section>
  )
}
