"use client"

import { useState, useEffect } from "react"
import { PlantCard } from "@/components/plant-card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { AlertCircle } from "lucide-react"

// Sample plant data for fallback
const FALLBACK_PLANTS = [
  {
    plant_id: "P001",
    common_name: "Snake Plant",
    scientific_name: "Sansevieria trifasciata",
    img_url: "/placeholder.svg?height=200&width=400&text=Snake+Plant",
    light_requirement: "Low",
    water_frequency: 14,
    humidity_preference: "Low",
    pet_friendly: false,
    suitable_locations: "Living room, Bedroom",
    care_difficulty: "Easy",
    match_score: 92,
  },
  {
    plant_id: "P002",
    common_name: "Peace Lily",
    scientific_name: "Spathiphyllum wallisii",
    img_url: "/placeholder.svg?height=200&width=400&text=Peace+Lily",
    light_requirement: "Medium",
    water_frequency: 7,
    humidity_preference: "High",
    pet_friendly: false,
    suitable_locations: "Living room, Bathroom",
    care_difficulty: "Moderate",
    match_score: 85,
  },
  {
    plant_id: "P003",
    common_name: "Spider Plant",
    scientific_name: "Chlorophytum comosum",
    img_url: "/placeholder.svg?height=200&width=400&text=Spider+Plant",
    light_requirement: "Medium",
    water_frequency: 7,
    humidity_preference: "Medium",
    pet_friendly: true,
    suitable_locations: "Living room, Kitchen, Bedroom",
    care_difficulty: "Easy",
    match_score: 78,
  },
]

export function PlantRecommendations() {
  const [recommendations, setRecommendations] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    // Fetch recommendations when component mounts
    const fetchRecommendations = async () => {
      try {
        setLoading(true)
        setError(null)

        // Use client-side data instead of making an API call
        // This avoids potential server-side errors
        setRecommendations(FALLBACK_PLANTS)
        setLoading(false)
      } catch (err) {
        console.error("Error in fetchRecommendations:", err)
        setError("Error loading recommendations. Using default plants instead.")
        // Still show fallback plants even if there's an error
        setRecommendations(FALLBACK_PLANTS)
        setLoading(false)
      }
    }

    fetchRecommendations()
  }, [])

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-[200px]">
        <div className="animate-pulse text-center">
          <div className="h-8 w-32 bg-gray-200 rounded mx-auto mb-4"></div>
          <div className="h-4 w-48 bg-gray-200 rounded mx-auto"></div>
        </div>
      </div>
    )
  }

  return (
    <div id="dashboard" className="py-8">
      <h2 className="text-3xl font-bold text-center mb-8">Your Plant Recommendations</h2>

      {error && (
        <Alert variant="destructive" className="mb-6">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Note</AlertTitle>
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      <Tabs defaultValue="all" className="w-full">
        <TabsList className="grid grid-cols-3 mb-8">
          <TabsTrigger value="all">All Plants</TabsTrigger>
          <TabsTrigger value="pet-friendly">Pet Friendly</TabsTrigger>
          <TabsTrigger value="easy-care">Easy Care</TabsTrigger>
        </TabsList>

        <TabsContent value="all">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {recommendations.map((plant) => (
              <PlantCard key={plant.plant_id} plant={plant} />
            ))}
          </div>
        </TabsContent>

        <TabsContent value="pet-friendly">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {recommendations
              .filter((plant) => plant.pet_friendly)
              .map((plant) => (
                <PlantCard key={plant.plant_id} plant={plant} />
              ))}
            {recommendations.filter((plant) => plant.pet_friendly).length === 0 && (
              <div className="col-span-full text-center py-8">
                <p className="text-muted-foreground">No pet-friendly plants found in your recommendations.</p>
              </div>
            )}
          </div>
        </TabsContent>

        <TabsContent value="easy-care">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {recommendations
              .filter((plant) => plant.care_difficulty === "Easy")
              .map((plant) => (
                <PlantCard key={plant.plant_id} plant={plant} />
              ))}
            {recommendations.filter((plant) => plant.care_difficulty === "Easy").length === 0 && (
              <div className="col-span-full text-center py-8">
                <p className="text-muted-foreground">No easy-care plants found in your recommendations.</p>
              </div>
            )}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
