import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { Microscope, Layout, Bug, Wind, BrainCircuit, Utensils, PaintBucket, Camera } from "lucide-react"

export function EnhancedFeatures() {
  const enhancedFeatures = [
    {
      icon: <Microscope className="h-8 w-8 text-green-600" />,
      title: "Plant Care Troubleshooting with GAI",
      description: "Describe your plant's symptoms and receive AI-powered diagnosis and treatment recommendations.",
      link: "/tools/troubleshoot",
    },
    {
      icon: <Layout className="h-8 w-8 text-blue-600" />,
      title: "Generative Plant Arrangement Design",
      description: "Generate creative plant arrangement designs based on your preferences and room constraints.",
      link: "/tools/arrangement-design",
    },
    {
      icon: <Bug className="h-8 w-8 text-red-600" />,
      title: "Plant Disease and Pest Detection",
      description: "Upload photos to identify early signs of plant diseases or pest infestations.",
      link: "/tools/disease-detection",
    },
    {
      icon: <Wind className="h-8 w-8 text-teal-600" />,
      title: "Air Quality Monitoring",
      description: "Get plant recommendations to target specific air quality concerns in your space.",
      link: "/tools/air-quality",
    },
    {
      icon: <BrainCircuit className="h-8 w-8 text-purple-600" />,
      title: "Explainable Plant Recommendations",
      description: "Understand exactly why certain plants are recommended for your space.",
      link: "/tools/explainable-ai",
    },
    {
      icon: <Utensils className="h-8 w-8 text-amber-600" />,
      title: "Plant-Based Recipes",
      description: "Discover culinary uses for your edible indoor plants with our recipe database.",
      link: "/tools/recipes",
    },
    {
      icon: <PaintBucket className="h-8 w-8 text-pink-600" />,
      title: "Plant-Inspired Design Suggestions",
      description: "Get decor ideas that complement your plant collection and enhance your space.",
      link: "/tools/design-suggestions",
    },
    {
      icon: <Camera className="h-8 w-8 text-indigo-600" />,
      title: "Plant Progress Tracking",
      description: "Create time-lapse visualizations of your plants' growth and development.",
      link: "/tools/progress-tracking",
    },
  ]

  return (
    <section className="py-20 bg-green-50">
      <div className="container mx-auto px-0">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl">Enhanced Features</h2>
          <p className="mt-4 text-lg text-gray-600 max-w-3xl mx-auto">
            Explore our advanced tools powered by artificial intelligence and data science to take your indoor gardening
            to the next level.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-2">
          {enhancedFeatures.map((feature, index) => (
            <Card key={index} className="hover:shadow-md transition-shadow">
              <div className="w-full h-30 overflow-hidden">
              </div>
              <CardHeader className="pb-2">
                <div className="mb-2">{feature.icon}</div>
                <CardTitle className="text-xl">{feature.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-gray-600 mb-4 min-h-[80px]">{feature.description}</CardDescription>
                <Button asChild variant="outline" className="w-full">
                  <Link href={feature.link}>Try Now</Link>
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
