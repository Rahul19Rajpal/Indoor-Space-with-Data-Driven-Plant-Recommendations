"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Droplets, Sun, ThermometerSun, Wind, Calendar, AlertTriangle, Check, Info } from "lucide-react"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "@/components/ui/chart"

// Sample data - in a real implementation, this would come from the Python backend
const sampleRecommendations = [
  {
    plant_id: "P001",
    common_name: "Snake Plant",
    family: "Liliaceae",
    categories: "Sansevieria",
    origin: "South Africa",
    climate: "Tropical",
    zone: "[11,10]",
    img_url: "http://www.tropicopia.com/house-plant/thumbnails/5735.jpg",
    light_requirement: "Low",
    water_frequency: 14, // days
    humidity_preference: "Low",
    maintenance_difficulty: 1,
    care_difficulty: "Easy",
    pet_friendly: false,
    suitable_locations: "Living room, Bedroom",
    match_score: 0.92,
    explanation: {
      overall_score: 0.92,
      factors: [
        {
          factor: "Light Requirements",
          value: "Low",
          explanation:
            "This plant thrives in low light conditions, making it perfect for spaces with limited natural light.",
        },
        {
          factor: "Maintenance Level",
          value: "Easy",
          explanation: "This plant is low-maintenance and forgiving, perfect for beginners or busy plant owners.",
        },
        {
          factor: "Pet Safety",
          value: "Not pet-friendly",
          explanation: "This plant may be toxic to pets and should be kept out of their reach.",
        },
        {
          factor: "Suitable Locations",
          value: "Living room, Bedroom",
          explanation: "This plant is well-suited for placement in: Living room, Bedroom.",
        },
      ],
    },
  },
  {
    plant_id: "P002",
    common_name: "Peace Lily",
    family: "Araceae",
    categories: "Spathiphyllum",
    origin: "Cultivar",
    climate: "Tropical",
    zone: "[11,10]",
    img_url: "http://www.tropicopia.com/house-plant/thumbnails/5758.jpg",
    light_requirement: "Medium",
    water_frequency: 7, // days
    humidity_preference: "High",
    maintenance_difficulty: 2,
    care_difficulty: "Moderate",
    pet_friendly: false,
    suitable_locations: "Living room, Bathroom",
    match_score: 0.87,
    explanation: {
      overall_score: 0.87,
      factors: [
        {
          factor: "Light Requirements",
          value: "Medium",
          explanation: "This plant thrives in medium light conditions, preferring bright, indirect light.",
        },
        {
          factor: "Maintenance Level",
          value: "Moderate",
          explanation: "This plant requires regular attention but is not overly demanding.",
        },
        {
          factor: "Pet Safety",
          value: "Not pet-friendly",
          explanation: "This plant may be toxic to pets and should be kept out of their reach.",
        },
        {
          factor: "Suitable Locations",
          value: "Living room, Bathroom",
          explanation: "This plant is well-suited for placement in: Living room, Bathroom.",
        },
      ],
    },
  },
  {
    plant_id: "P003",
    common_name: "Spider Plant",
    family: "Liliaceae",
    categories: "Hanging",
    origin: "Central Africa",
    climate: "Tropical to subtropical",
    zone: "[11, 9]",
    img_url: "http://www.tropicopia.com/house-plant/thumbnails/5527.jpg",
    light_requirement: "Medium",
    water_frequency: 7, // days
    humidity_preference: "Medium",
    maintenance_difficulty: 1,
    care_difficulty: "Easy",
    pet_friendly: true,
    suitable_locations: "Living room, Kitchen, Bedroom",
    match_score: 0.85,
    explanation: {
      overall_score: 0.85,
      factors: [
        {
          factor: "Light Requirements",
          value: "Medium",
          explanation: "This plant thrives in medium light conditions, preferring bright, indirect light.",
        },
        {
          factor: "Maintenance Level",
          value: "Easy",
          explanation: "This plant is low-maintenance and forgiving, perfect for beginners or busy plant owners.",
        },
        {
          factor: "Pet Safety",
          value: "Pet-friendly",
          explanation: "This plant is safe for households with pets.",
        },
        {
          factor: "Suitable Locations",
          value: "Living room, Kitchen, Bedroom",
          explanation: "This plant is well-suited for placement in: Living room, Kitchen, Bedroom.",
        },
      ],
    },
  },
  {
    plant_id: "P004",
    common_name: "Pothos",
    family: "Araceae",
    categories: "Hanging",
    origin: "South Pacific",
    climate: "Tropical",
    zone: "[11,10]",
    img_url: "http://www.tropicopia.com/house-plant/thumbnails/5594.jpg",
    light_requirement: "Low-Medium",
    water_frequency: 10, // days
    humidity_preference: "Medium",
    maintenance_difficulty: 1,
    care_difficulty: "Easy",
    pet_friendly: false,
    suitable_locations: "Living room, Office, Bedroom",
    match_score: 0.83,
    explanation: {
      overall_score: 0.83,
      factors: [
        {
          factor: "Light Requirements",
          value: "Low-Medium",
          explanation: "This plant is adaptable to various light conditions, from low to medium light.",
        },
        {
          factor: "Maintenance Level",
          value: "Easy",
          explanation: "This plant is low-maintenance and forgiving, perfect for beginners or busy plant owners.",
        },
        {
          factor: "Pet Safety",
          value: "Not pet-friendly",
          explanation: "This plant may be toxic to pets and should be kept out of their reach.",
        },
        {
          factor: "Suitable Locations",
          value: "Living room, Office, Bedroom",
          explanation: "This plant is well-suited for placement in: Living room, Office, Bedroom.",
        },
      ],
    },
  },
  {
    plant_id: "P005",
    common_name: "ZZ Plant",
    family: "Araceae",
    categories: "Foliage plant",
    origin: "South Africa",
    climate: "Tropical",
    zone: "[11,10]",
    img_url: "http://www.tropicopia.com/house-plant/thumbnails/5789.jpg",
    light_requirement: "Low",
    water_frequency: 14, // days
    humidity_preference: "Low",
    maintenance_difficulty: 1,
    care_difficulty: "Easy",
    pet_friendly: false,
    suitable_locations: "Living room, Office, Bedroom",
    match_score: 0.81,
    explanation: {
      overall_score: 0.81,
      factors: [
        {
          factor: "Light Requirements",
          value: "Low",
          explanation:
            "This plant thrives in low light conditions, making it perfect for spaces with limited natural light.",
        },
        {
          factor: "Maintenance Level",
          value: "Easy",
          explanation: "This plant is low-maintenance and forgiving, perfect for beginners or busy plant owners.",
        },
        {
          factor: "Pet Safety",
          value: "Not pet-friendly",
          explanation: "This plant may be toxic to pets and should be kept out of their reach.",
        },
        {
          factor: "Suitable Locations",
          value: "Living room, Office, Bedroom",
          explanation: "This plant is well-suited for placement in: Living room, Office, Bedroom.",
        },
      ],
    },
  },
]

// Chart data
const lightDistributionData = [
  { name: "Low", value: 2 },
  { name: "Medium", value: 2 },
  { name: "High", value: 1 },
]

const maintenanceData = [
  { name: "Easy", value: 3 },
  { name: "Moderate", value: 1 },
  { name: "Difficult", value: 1 },
]

const COLORS = ["#4CAF50", "#8BC34A", "#CDDC39", "#FFC107", "#FF9800"]

export function PlantDashboard() {
  const [recommendations, setRecommendations] = useState(sampleRecommendations)
  const [selectedPlant, setSelectedPlant] = useState(sampleRecommendations[0])
  const [loading, setLoading] = useState(false)

  // In a real implementation, this would fetch data from the Python backend
  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true)
        // In a real implementation, this would be an API call
        // const response = await fetch('/api/recommendations')
        // const data = await response.json()
        // setRecommendations(data.recommendations)
        // setSelectedPlant(data.recommendations[0])

        // Simulate API call with timeout
        setTimeout(() => {
          setLoading(false)
        }, 1000)
      } catch (error) {
        console.error("Error fetching recommendations:", error)
        setLoading(false)
      }
    }

    fetchData()
  }, [])

  return (
    <div className="space-y-8">
      <div className="text-center">
        <h2 className="text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl">Your Plant Recommendations</h2>
        <p className="mt-4 text-lg text-gray-600">
          Based on your preferences, here are the best plants for your space.
        </p>
      </div>

      {loading ? (
        <div className="flex justify-center items-center py-12">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600"></div>
        </div>
      ) : (
        <Tabs defaultValue="recommendations" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="recommendations">Recommendations</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
            <TabsTrigger value="maintenance">Maintenance</TabsTrigger>
          </TabsList>

          <TabsContent value="recommendations" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="md:col-span-1 space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Top Matches</CardTitle>
                    <CardDescription>Plants that best match your preferences</CardDescription>
                  </CardHeader>
                  <CardContent className="p-0">
                    <ul className="divide-y">
                      {recommendations.map((plant) => (
                        <li
                          key={plant.plant_id}
                          className={`p-4 cursor-pointer hover:bg-gray-50 ${selectedPlant.plant_id === plant.plant_id ? "bg-green-50" : ""}`}
                          onClick={() => setSelectedPlant(plant)}
                        >
                          <div className="flex items-center justify-between">
                            <div className="flex items-center">
                              <div className="h-10 w-10 rounded-full overflow-hidden mr-3">
                                <img
                                  src={plant.img_url || "/placeholder.svg"}
                                  alt={plant.common_name}
                                  className="h-full w-full object-cover"
                                />
                              </div>
                              <div>
                                <p className="font-medium">{plant.common_name}</p>
                                <p className="text-sm text-gray-500">{plant.family}</p>
                              </div>
                            </div>
                            <div className="text-right">
                              <Badge variant={plant.match_score > 0.85 ? "default" : "secondary"}>
                                {Math.round(plant.match_score * 100)}% Match
                              </Badge>
                            </div>
                          </div>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              </div>

              <div className="md:col-span-2">
                <Card className="h-full">
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle>{selectedPlant.common_name}</CardTitle>
                        <CardDescription>
                          {selectedPlant.family} - {selectedPlant.categories}
                        </CardDescription>
                      </div>
                      <Badge variant="outline" className="ml-2">
                        {Math.round(selectedPlant.match_score * 100)}% Match
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="flex flex-col md:flex-row gap-6">
                      <div className="flex-shrink-0 w-full md:w-1/3">
                        <div className="rounded-lg overflow-hidden h-48 bg-gray-100">
                          <img
                            src={selectedPlant.img_url || "/placeholder.svg"}
                            alt={selectedPlant.common_name}
                            className="w-full h-full object-cover"
                          />
                        </div>
                      </div>
                      <div className="flex-grow">
                        <p className="text-gray-700 mb-4">
                          A {selectedPlant.common_name.toLowerCase()} from {selectedPlant.origin}, native to{" "}
                          {selectedPlant.climate.toLowerCase()} climates. This plant is perfect for{" "}
                          {selectedPlant.suitable_locations.toLowerCase()}.
                        </p>
                        <div className="grid grid-cols-2 gap-4">
                          <div className="flex items-center">
                            <Sun className="h-5 w-5 text-yellow-500 mr-2" />
                            <span className="text-sm">Light: {selectedPlant.light_requirement}</span>
                          </div>
                          <div className="flex items-center">
                            <Droplets className="h-5 w-5 text-blue-500 mr-2" />
                            <span className="text-sm">Water: Every {selectedPlant.water_frequency} days</span>
                          </div>
                          <div className="flex items-center">
                            <Wind className="h-5 w-5 text-teal-500 mr-2" />
                            <span className="text-sm">Humidity: {selectedPlant.humidity_preference}</span>
                          </div>
                          <div className="flex items-center">
                            <ThermometerSun className="h-5 w-5 text-orange-500 mr-2" />
                            <span className="text-sm">Maintenance: {selectedPlant.care_difficulty}</span>
                          </div>
                        </div>
                        <div className="mt-4 flex items-center">
                          {selectedPlant.pet_friendly ? (
                            <Badge
                              variant="outline"
                              className="bg-green-50 text-green-700 border-green-200 flex items-center"
                            >
                              <Check className="h-3 w-3 mr-1" /> Pet Friendly
                            </Badge>
                          ) : (
                            <Badge
                              variant="outline"
                              className="bg-red-50 text-red-700 border-red-200 flex items-center"
                            >
                              <AlertTriangle className="h-3 w-3 mr-1" /> Not Pet Safe
                            </Badge>
                          )}
                        </div>
                      </div>
                    </div>

                    <div>
                      <h4 className="font-medium mb-2">Why this plant matches your preferences:</h4>
                      <ul className="space-y-2">
                        {selectedPlant.explanation.factors.map((factor, index) => (
                          <li key={index} className="flex items-start">
                            <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5" />
                            <span>{factor.explanation}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button className="w-full bg-green-600 hover:bg-green-700">Add to My Plants</Button>
                  </CardFooter>
                </Card>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="analytics" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Light Requirements Distribution</CardTitle>
                  <CardDescription>Distribution of light requirements among recommended plants</CardDescription>
                </CardHeader>
                <CardContent className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={lightDistributionData}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                        label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                      >
                        {lightDistributionData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Maintenance Level Distribution</CardTitle>
                  <CardDescription>Distribution of maintenance levels among recommended plants</CardDescription>
                </CardHeader>
                <CardContent className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={maintenanceData}
                      margin={{
                        top: 20,
                        right: 30,
                        left: 20,
                        bottom: 5,
                      }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Bar dataKey="value" name="Number of Plants" fill="#4CAF50" />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Match Score Analysis</CardTitle>
                <CardDescription>Detailed breakdown of match scores for recommended plants</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {recommendations.map((plant) => (
                    <div key={plant.plant_id} className="space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center">
                          <div className="h-8 w-8 rounded-full overflow-hidden mr-3">
                            <img
                              src={plant.img_url || "/placeholder.svg"}
                              alt={plant.common_name}
                              className="h-full w-full object-cover"
                            />
                          </div>
                          <span className="font-medium">{plant.common_name}</span>
                        </div>
                        <span className="text-sm font-medium">{Math.round(plant.match_score * 100)}%</span>
                      </div>
                      <Progress value={plant.match_score * 100} className="h-2" />
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="maintenance" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Maintenance Schedule</CardTitle>
                <CardDescription>Recommended care schedule for your selected plants</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {recommendations.map((plant) => (
                    <div key={plant.plant_id} className="border rounded-lg p-4">
                      <div className="flex items-center justify-between mb-4">
                        <div className="flex items-center">
                          <div className="h-10 w-10 rounded-full overflow-hidden mr-3">
                            <img
                              src={plant.img_url || "/placeholder.svg"}
                              alt={plant.common_name}
                              className="h-full w-full object-cover"
                            />
                          </div>
                          <div>
                            <p className="font-medium">{plant.common_name}</p>
                            <p className="text-sm text-gray-500">{plant.family}</p>
                          </div>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div className="flex items-center p-3 bg-blue-50 rounded-lg">
                          <Droplets className="h-5 w-5 text-blue-500 mr-2" />
                          <div>
                            <p className="text-sm font-medium">Watering</p>
                            <p className="text-xs text-gray-600">Every {plant.water_frequency} days</p>
                          </div>
                        </div>

                        <div className="flex items-center p-3 bg-yellow-50 rounded-lg">
                          <Sun className="h-5 w-5 text-yellow-500 mr-2" />
                          <div>
                            <p className="text-sm font-medium">Light</p>
                            <p className="text-xs text-gray-600">{plant.light_requirement}</p>
                          </div>
                        </div>

                        <div className="flex items-center p-3 bg-green-50 rounded-lg">
                          <Calendar className="h-5 w-5 text-green-500 mr-2" />
                          <div>
                            <p className="text-sm font-medium">Next Care</p>
                            <p className="text-xs text-gray-600">In {Math.floor(Math.random() * 7) + 1} days</p>
                          </div>
                        </div>
                      </div>

                      <div className="mt-4">
                        <h4 className="text-sm font-medium mb-2">Care Instructions:</h4>
                        <ul className="text-sm text-gray-600 space-y-1">
                          <li className="flex items-start">
                            <Info className="h-4 w-4 text-gray-400 mr-2 mt-0.5" />
                            <span>
                              Water thoroughly when the top {plant.water_frequency <= 7 ? "1-2" : "2-3"} inches of soil
                              are dry.
                            </span>
                          </li>
                          <li className="flex items-start">
                            <Info className="h-4 w-4 text-gray-400 mr-2 mt-0.5" />
                            <span>
                              {plant.humidity_preference === "High"
                                ? "Mist regularly to maintain high humidity."
                                : plant.humidity_preference === "Medium"
                                  ? "Occasional misting is beneficial, especially in dry conditions."
                                  : "No need for additional humidity measures."}
                            </span>
                          </li>
                          <li className="flex items-start">
                            <Info className="h-4 w-4 text-gray-400 mr-2 mt-0.5" />
                            <span>
                              {plant.care_difficulty === "Easy"
                                ? "Minimal maintenance required. Check occasionally for dust on leaves."
                                : plant.care_difficulty === "Moderate"
                                  ? "Regular inspection for pests and pruning of dead leaves recommended."
                                  : "Requires attentive care. Monitor closely for changes in appearance."}
                            </span>
                          </li>
                        </ul>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      )}
    </div>
  )
}
