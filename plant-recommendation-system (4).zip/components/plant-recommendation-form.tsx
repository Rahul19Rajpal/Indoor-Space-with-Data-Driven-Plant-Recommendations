"use client"

import type React from "react"

import { useState } from "react"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import * as z from "zod"
import { useToast } from "@/components/ui/use-toast"

import { Button } from "@/components/ui/button"
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { Slider } from "@/components/ui/slider"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Loader2, Upload } from "lucide-react"
import { PlantCard } from "@/components/plant-card"

const formSchema = z.object({
  roomType: z.string({
    required_error: "Please select a room type",
  }),
  lightLevel: z.string({
    required_error: "Please select a light level",
  }),
  maintenanceLevel: z.string({
    required_error: "Please select a maintenance level",
  }),
  petFriendly: z.boolean().default(false),
  humidity: z.number().min(0).max(100).default(50),
  temperature: z.number().min(10).max(35).default(22),
})

export function PlantRecommendationForm() {
  const { toast } = useToast()
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [photoPreview, setPhotoPreview] = useState<string | null>(null)
  const [photoFile, setPhotoFile] = useState<File | null>(null)
  const [recommendations, setRecommendations] = useState<any[]>([])

  // Generate random default values
  const roomTypes = ["living_room", "bedroom", "bathroom", "kitchen", "office"]
  const lightLevels = ["low", "medium", "high"]
  const maintenanceLevels = ["low", "medium", "high"]

  const randomRoomType = roomTypes[Math.floor(Math.random() * roomTypes.length)]
  const randomLightLevel = lightLevels[Math.floor(Math.random() * lightLevels.length)]
  const randomMaintenanceLevel = maintenanceLevels[Math.floor(Math.random() * maintenanceLevels.length)]
  const randomPetFriendly = Math.random() > 0.5
  const randomHumidity = Math.floor(Math.random() * 40) + 30 // Random between 30-70
  const randomTemperature = Math.floor(Math.random() * 10) + 18 // Random between 18-28

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      roomType: randomRoomType,
      lightLevel: randomLightLevel,
      maintenanceLevel: randomMaintenanceLevel,
      petFriendly: randomPetFriendly,
      humidity: randomHumidity,
      temperature: randomTemperature,
    },
  })

  async function onSubmit(values: z.infer<typeof formSchema>) {
    setIsSubmitting(true)

    try {
      // Call our API endpoint
      const response = await fetch("/api/recommend-plants", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          preferences: {
            room_type: values.roomType,
            light_level: values.lightLevel,
            maintenance: values.maintenanceLevel,
            pet_safe: values.petFriendly,
            humidity: values.humidity,
            temperature: values.temperature,
          },
        }),
      })

      const data = await response.json()

      if (!data.success) {
        console.error("API returned error:", data.error)
        if (data.recommendations && data.recommendations.length > 0) {
          // If we have mock recommendations despite the error, use them
          setRecommendations(data.recommendations)
          toast({
            title: "Using sample recommendations",
            description: "We're showing sample plants while we fix some issues.",
          })
        } else {
          throw new Error(data.error || "Failed to get recommendations")
        }
      } else {
        // Set recommendations
        setRecommendations(data.recommendations)

        if (data.mockData) {
          toast({
            title: "Using sample recommendations",
            description: "We're showing sample plants while we fix some issues.",
          })
        } else {
          toast({
            title: "Recommendations generated!",
            description: "Scroll down to see your personalized plant recommendations.",
          })
        }
      }

      document.getElementById("recommendations")?.scrollIntoView({ behavior: "smooth" })
    } catch (error) {
      console.error("Error fetching recommendations:", error)

      // Generate mock recommendations as a fallback
      const mockRecommendations = [
        {
          plant_id: "fallback_1",
          common_name: "Snake Plant",
          scientific_name: "Sansevieria trifasciata",
          light_level: "low",
          maintenance: "low",
          water_frequency: "low",
          pet_safe: true,
          air_purifying: true,
          humidity: "low",
          temperature_min: 18,
          temperature_max: 27,
          room_type: ["bedroom", "living_room", "office"],
          size: "medium",
          growth_rate: "slow",
          description: "One of the most tolerant houseplants that thrives in almost any condition.",
          image_url: "/placeholder.svg?height=300&width=300&text=Snake+Plant",
          match_score: 95,
          explanation:
            "Snake Plant is perfect for your preferences because it requires minimal maintenance, thrives in low light conditions, and is pet-friendly. It's also excellent for air purification.",
        },
        {
          plant_id: "fallback_2",
          common_name: "Pothos",
          scientific_name: "Epipremnum aureum",
          light_level: "low to medium",
          maintenance: "low",
          water_frequency: "medium",
          pet_safe: false,
          air_purifying: true,
          humidity: "medium",
          temperature_min: 18,
          temperature_max: 30,
          room_type: ["living_room", "office", "kitchen"],
          size: "medium",
          growth_rate: "fast",
          description: "A trailing vine with heart-shaped leaves that's nearly impossible to kill.",
          image_url: "/placeholder.svg?height=300&width=300&text=Pothos",
          match_score: 90,
          explanation:
            "Pothos matches your preferences for low maintenance and adaptability to various light conditions. Note that it's not pet-friendly, but it's excellent for air purification and grows well in most indoor environments.",
        },
        {
          plant_id: "fallback_3",
          common_name: "ZZ Plant",
          scientific_name: "Zamioculcas zamiifolia",
          light_level: "low to medium",
          maintenance: "low",
          water_frequency: "low",
          pet_safe: false,
          air_purifying: true,
          humidity: "low",
          temperature_min: 18,
          temperature_max: 26,
          room_type: ["bedroom", "living_room", "office"],
          size: "medium",
          growth_rate: "slow",
          description: "A striking plant with glossy leaves that can survive months of neglect.",
          image_url: "/placeholder.svg?height=300&width=300&text=ZZ+Plant",
          match_score: 88,
          explanation:
            "ZZ Plant is extremely low maintenance and thrives in low light conditions, making it perfect for your preferences. It's not pet-friendly but is very drought-tolerant and air-purifying.",
        },
      ]

      setRecommendations(mockRecommendations)

      toast({
        title: "Using sample recommendations",
        description: "We're showing sample plants while we fix some issues.",
        variant: "default",
      })

      document.getElementById("recommendations")?.scrollIntoView({ behavior: "smooth" })
    } finally {
      setIsSubmitting(false)
    }
  }

  const handlePhotoUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) {
      setPhotoFile(file)
      const reader = new FileReader()
      reader.onload = (e) => {
        setPhotoPreview(e.target?.result as string)
      }
      reader.readAsDataURL(file)
    }
  }

  return (
    <div className="max-w-3xl mx-auto">
      <Card>
        <CardContent className="pt-6">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <FormField
                  control={form.control}
                  name="roomType"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Room Type</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select a room type" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="living_room">Living Room</SelectItem>
                          <SelectItem value="bedroom">Bedroom</SelectItem>
                          <SelectItem value="bathroom">Bathroom</SelectItem>
                          <SelectItem value="kitchen">Kitchen</SelectItem>
                          <SelectItem value="office">Office</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormDescription>Where will you place your plants?</FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="lightLevel"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Light Level</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select light level" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="low">Low (Shade)</SelectItem>
                          <SelectItem value="medium">Medium (Indirect Light)</SelectItem>
                          <SelectItem value="high">High (Direct Sunlight)</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormDescription>How much light does your space receive?</FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <FormField
                  control={form.control}
                  name="maintenanceLevel"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Maintenance Level</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select maintenance level" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="low">Low (Easy Care)</SelectItem>
                          <SelectItem value="medium">Medium (Regular Care)</SelectItem>
                          <SelectItem value="high">High (Frequent Care)</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormDescription>How much time can you dedicate to plant care?</FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="petFriendly"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                      <div className="space-y-0.5">
                        <FormLabel className="text-base">Pet-Friendly Plants</FormLabel>
                        <FormDescription>Only show plants that are safe for pets</FormDescription>
                      </div>
                      <FormControl>
                        <Switch checked={field.value} onCheckedChange={field.onChange} />
                      </FormControl>
                    </FormItem>
                  )}
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <FormField
                  control={form.control}
                  name="humidity"
                  render={({ field: { value, onChange } }) => (
                    <FormItem>
                      <FormLabel>Humidity Level (%): {value}</FormLabel>
                      <FormControl>
                        <Slider
                          min={0}
                          max={100}
                          step={5}
                          value={[value]}
                          onValueChange={(vals) => onChange(vals[0])}
                          className="py-4"
                        />
                      </FormControl>
                      <FormDescription>Approximate humidity level in your space</FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="temperature"
                  render={({ field: { value, onChange } }) => (
                    <FormItem>
                      <FormLabel>Temperature (°C): {value}</FormLabel>
                      <FormControl>
                        <Slider
                          min={10}
                          max={35}
                          step={1}
                          value={[value]}
                          onValueChange={(vals) => onChange(vals[0])}
                          className="py-4"
                        />
                      </FormControl>
                      <FormDescription>Average temperature in your space</FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <div className="border rounded-lg p-4">
                <Label htmlFor="room-photo" className="block mb-2">
                  Upload a photo of your space (optional)
                </Label>
                <div className="flex items-center gap-4">
                  <div className="flex-1">
                    <div className="relative border-2 border-dashed rounded-lg p-4 text-center cursor-pointer hover:bg-gray-50">
                      <Input
                        id="room-photo"
                        type="file"
                        accept="image/*"
                        className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                        onChange={handlePhotoUpload}
                      />
                      <Upload className="mx-auto h-8 w-8 text-gray-400" />
                      <p className="mt-1 text-sm text-gray-500">Click to upload or drag and drop</p>
                      <p className="text-xs text-gray-500">PNG, JPG, GIF up to 10MB</p>
                    </div>
                  </div>
                  {photoPreview && (
                    <div className="w-24 h-24 relative rounded-md overflow-hidden">
                      <img
                        src={photoPreview || "/placeholder.svg"}
                        alt="Room preview"
                        className="w-full h-full object-cover"
                      />
                    </div>
                  )}
                </div>
              </div>

              <Button type="submit" className="w-full bg-green-600 hover:bg-green-700" disabled={isSubmitting}>
                {isSubmitting ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Generating Recommendations...
                  </>
                ) : (
                  "Get Plant Recommendations"
                )}
              </Button>
            </form>
          </Form>
        </CardContent>
      </Card>

      {recommendations.length > 0 && (
        <div id="recommendations" className="mt-12">
          <h2 className="text-2xl font-bold mb-6">Your Plant Recommendations</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {recommendations.map((plant, index) => (
              <PlantCard key={plant.plant_id || `plant-${index}`} plant={plant} />
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
