import { Leaf, Droplets, Sun, Calendar, LineChart, Lightbulb, Palette, Shield } from "lucide-react"

export function Features() {
  const features = [
    {
      icon: <Leaf className="h-10 w-10 text-green-600" />,
      title: "Personalized Recommendations",
      description: "Get plant suggestions tailored to your specific indoor environment and preferences.",
    },
    {
      icon: <Droplets className="h-10 w-10 text-blue-600" />,
      title: "Dynamic Maintenance Scheduler",
      description: "Receive customized care schedules based on your plants' needs and environmental conditions.",
    },
    {
      icon: <Sun className="h-10 w-10 text-yellow-600" />,
      title: "Light Analysis",
      description: "Understand the light conditions in your space and find plants that will thrive there.",
    },
    {
      icon: <Calendar className="h-10 w-10 text-purple-600" />,
      title: "Seasonal Adaptations",
      description: "Get advice on how to adjust care routines as seasons change.",
    },
    {
      icon: <LineChart className="h-10 w-10 text-indigo-600" />,
      title: "Data-Driven Insights",
      description: "Benefit from machine learning algorithms that analyze plant performance data.",
    },
    {
      icon: <Lightbulb className="h-10 w-10 text-amber-600" />,
      title: "Educational Resources",
      description: "Access comprehensive information about plant care and indoor gardening.",
    },
    {
      icon: <Palette className="h-10 w-10 text-pink-600" />,
      title: "Aesthetic Arrangement",
      description: "Discover optimal plant arrangements that enhance your space's visual appeal.",
    },
    {
      icon: <Shield className="h-10 w-10 text-red-600" />,
      title: "Pet-Safe Options",
      description: "Identify plants that are safe for homes with pets and children.",
    },
  ]

  return (
    <section id="features" className="py-20 bg-white">
      <div className="w-full px-0">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl">Key Features</h2>
          <p className="mt-4 text-lg text-gray-600 max-w-3xl mx-auto">
            Our system combines data science, machine learning, and horticultural expertise to provide a comprehensive
            indoor plant management solution.
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-2">
          {features.map((feature, index) => (
            <div key={index} className="bg-gray-50 p-6 rounded-lg shadow-sm hover:shadow-md transition-shadow">
              <div className="mb-4 flex flex-col items-center">
                <div className="w-full h-25 rounded-lg overflow-hidden mb-4">
                </div>
                {feature.icon}
              </div>
              <h3 className="text-xl font-semibold mb-2 text-center">{feature.title}</h3>
              <p className="text-gray-600">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
